
#pragma once

typedef unsigned char UInt8;
typedef unsigned short UInt16;
typedef unsigned int UInt32;
typedef uint64_t UInt64;
typedef char Int8;
typedef short Int16;
typedef int Int32;
typedef int64_t Int64;



typedef void (*ManagedEventCallback)();

// These must be greater than 0, as negative numbers represent errors. Nothing larger than 0x7FFFFFFF
const int g_synchronousRequestIdStart = 0x60000000;
const int g_customNpRequestIdStart = 0x70000000;

// This can be larger than 0x7FFFFFFF as custom notifications don't return errors codes in the same way as requests do.
const int g_customNotificationRequestIdStart = 0xF0000000;
