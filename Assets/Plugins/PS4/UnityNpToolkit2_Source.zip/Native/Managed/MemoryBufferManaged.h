#pragma once

#include "../Includes/SonyCommonIncludes.h"
#include "../ErrorHandling/Errors.h"
#include "../Threading/Threading.h"

#include <list>

namespace NPT
{
	// Up to 256 integrity markers can be added to validate
	// different structures being written into the buffer
	enum class BufferIntegrityChecks
	{
		BufferBegin = 0,		// The start marker in the buffer
		BufferEnd,				// The end marker of the buffer

		// Core
		OnlineUserBegin,
		OnlineUserEnd,

		NpOnlineIdBegin,
		NpOnlineIdEnd,

		SceNpIdBegin,
		SceNpIdEnd,

		NpCountryCodeBegin,
		NpCountryCodeEnd,

		NpTitleIdBegin,
		NpTitleIdEnd,

		NpLanguageCodeBegin,
		NpLanguageCodeEnd,

		PNGBegin,
		PNGEnd,

		// Friends
		FriendsBegin,
		FriendsEnd,

		FriendBegin,
		FriendEnd,

		FriendsOfFriendsBegin,
		FriendsOfFriendsEnd,

		BlockedUsersBegin,
		BlockedUsersEnd,

		// Profile
		ProfileBegin,
		ProfileEnd,

		RealNameBegin,
		RealNameEnd,

		// Presence
		PresenceBegin,
		PresenceEnd,

		PlatformPresenceBegin,
		PlatformPresenceEnd,

		// User Profiles
		NpProfilesBegin,
		NpProfilesEnd,

		// Network Utils
		BandwidthInfoBegin,
		BandwidthInfoEnd,

		NetStateBasicBegin,
		NetStateBasicEnd,

		NetStateDetailedBegin,
		NetStateDetailedEnd,

		// Trophies
		UnlockedTrophiesBegin,
		UnlockedTrophiesEnd,

		TrophyPackSummaryBegin,
		TrophyPackSummaryEnd,

		TrophyPackGroupBegin,
		TrophyPackGroupEnd,

		TrophyPackTrophyBegin,
		TrophyPackTrophyEnd,

		// Ranking
		TempRankBegin,
		TempRankEnd,

		RangeOfRanksBegin,
		RangeOfRanksEnd,

		FriendsRanksBegin,
		FriendsRanksEnd,

		UsersRanksBegin,
		UsersRanksEnd,

		SetGameDataBegin,
		SetGameDataEnd,

		GetGameDataBegin,
		GetGameDataEnd,

		// Matching
		WorldsBegin,
		WorldsEnd,

		CreateRoomBegin,
		CreateRoomEnd,

		RoomBegin,
		RoomEnd,

		RoomsBegin,
		RoomsEnd,

		RoomPingTimeBegin,
		RoomPingTimeEnd,

		GetDataBegin,
		GetDataEnd,

		// Tss	
		TssDataBegin,
		TssDataEnd,

		// Tus	
		TusVariablesBegin,
		TusVariablesEnd,

		TusAtomicAddToAndGetVariableBegin,
		TusAtomicAddToAndGetVariableEnd,

		TusDataBegin,
		TusDataEnd,

		TusFriendsVariablesBegin,
		TusFriendsVariablesEnd,

		TusDataStatusesBegin,
		TusDataStatusesEnd,

		TusFriendsDataStatusesBegin,
		TusFriendsDataStatusesEnd,

		// Messaging
		GameDataMessagesBegin,
		GameDataMessagesEnd,

		GameDataMessageThumbnailBegin,
		GameDataMessageThumbnailEnd,

		GameDataMessageAttachmentBegin,
		GameDataMessageAttachmentEnd,

		GameDataMessageBegin,
		GameDataMessageEnd,

		GameDataMessageDetailsBegin,
		GameDataMessageDetailsEnd,

		// Commerce
		CategoriesBegin,
		CategoriesEnd,

		CategoryBegin,
		CategoryEnd,

		SubCategoryBegin,
		SubCategoryEnd,

		ProductsBegin,
		ProductsEnd,

		ProductBegin,
		ProductEnd,

		ProductDetailsBegin,
		ProductDetailsEnd,

		SkuInfoBegin,
		SkuInfoEnd,

		ServiceEntitlementsBegin,
		ServiceEntitlementsEnd,

		ServiceEntitlementBegin,
		ServiceEntitlementEnd,

		// Auth
	
		AuthCodeBegin,
		AuthCodeEnd,

		IdTokenBegin,
		IdTokenEnd,

		// WordFilter

		WordFilterBegin,
		WordFilterEnd,

		// Notifications
		FriendListUpdateBegin,
		FriendListUpdateEnd,

		BlocklistUpdateBegin,
		BlocklistUpdateEnd,

		PresenceUpdateBegin,
		PresenceUpdateEnd,

		UserStateChangeBegin,
		UserStateChangeEnd,

		NetStateChangeBegin,
		NetStateChangeEnd,

		RefreshRoomBegin,
		RefreshRoomEnd,

		InvitationReceivedBegin,
		InvitationReceivedEnd,

		NewRoomMessageBegin,
		NewRoomMessageEnd,

		NewInGameMessageBegin,
		NewInGameMessageEnd,

		NewGameDataMessageBegin,
		NewGameDataMessageEnd,

		// Custom Notifications
		SessionInvitationEventBegin,
		SessionInvitationEventEnd,

		PlayTogetherHostEventBegin,
		PlayTogetherHostEventEnd,

		GameCustomDataEventBegin,
		GameCustomDataEventEnd,

		LaunchAppEventBegin,
	    LaunchAppEventEnd,

		// Custom Requests
		CheckPlusBegin,
		CheckPlusEnd,

		GetParentalControlInfoBegin,
		GetParentalControlInfoEnd,

		// Activity Feed
		GetFeedBegin,
		GetFeedEnd,

		StoryBegin,
		StoryEnd,

		StoryUserBegin,
		StoryUserEnd,

		UsersWhoLikedBegin,
		UsersWhoLikedEnd,

		PlayedWithFeedBegin,
		PlayedWithFeedEnd,

		SharedVideosBegin,
		SharedVideosEnd,

		SharedVideoBegin,
		SharedVideoEnd,
	};

	struct MemoryBufferManaged
	{
		UInt32 length;
		void* data;
	};

	class MemoryBuffer
	{
		const static Int32 MAX_BUFFERS = 5;
		const static Int32 MAX_BUFFER_SIZE = 1024*1024;

		void* data;
		UInt32 defaultBufferSize;
		UInt32 maxBufferSize;
		char* pos;

		static MemoryBuffer* s_MemoryBufferQueue[MAX_BUFFERS];
		static UInt32 s_NextQueueIndex;
		static UInt32 s_EmptyQueueIndex;
		static PlatformSemaphore s_Semaphore;
		static Mutex s_Mutex;

	public:

		void CopyTo(MemoryBufferManaged* destination);

		MemoryBuffer(UInt32 defaultSize);

		static void Initialise();
		static void Shutdown();
		static MemoryBuffer& GetNextFreeBuffer();
		static void ReleaseBuffer(MemoryBuffer& buffer);

		void StartResponseWrite();	
		void FinishResponseWrite();

		void Reset();

		void WriteMarker(BufferIntegrityChecks value);

		void WriteBool(bool value); // Write 1 byte

		void WriteInt8(Int8 value); 
		void WriteUInt8(UInt8 value); 

		void WriteInt16(Int16 value); 
		void WriteUInt16(UInt16 value); 

		void WriteInt32(Int32 value);
		void WriteUInt32(UInt32 value);

		void WriteInt64(Int64 value);
		void WriteUInt64(UInt64 value);

		void WritePtr(void* ptr);

		void WriteDouble(double value);

		void WriteData(const char* data, UInt32 size);

		void WriteString(const char* str);
		void WriteString(const char* str, UInt32 size);

	private:
		void GrowBuffer(size_t requiredSize);
	};

	
}