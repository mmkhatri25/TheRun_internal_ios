#pragma once

#include "../Includes/SonyCommonIncludes.h"
#include "../Includes/CommonTypes.h"

namespace NPT
{
	// A marshalled version of RequestBase (common_defines.h)
	class RequestBaseManaged
	{
	public:
		Int32 serviceType;
		Int32 functionType;
		SceNpServiceLabel serviceLabel;			///< Service Label for the service, as configured in DevNet Forms
		Int32 userId;
		bool async;
		UInt32 padding;

		void CopyTo(NpToolkit2::Core::RequestBase &destination);

		//static NpToolkit2::Core::FunctionType ConvertFromManagedEnum(NpToolkit2::Core::FunctionType apiCalled);
		//static NpToolkit2::Core::FunctionType ConvertToManagedEnum(NpToolkit2::Core::FunctionType apiCalled);
	};

}
