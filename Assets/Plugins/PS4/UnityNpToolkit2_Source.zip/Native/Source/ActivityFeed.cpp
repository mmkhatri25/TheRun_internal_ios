
#include "ActivityFeed.h"

#include "Core.h"
#include "Profile.h"

namespace NPT
{
	DO_EXPORT( int, PrxGetFeed ) (GetFeedManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::GetFeed(managedRequest, result);
	}

	DO_EXPORT(int, PrxPostInGameStory) (PostInGameStoryManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::PostInGameStory(managedRequest, result);
	}

	DO_EXPORT(int, PrxSetLiked) (SetLikedManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::SetLiked(managedRequest, result);
	}

	DO_EXPORT(int, PrxGetWhoLiked) (GetWhoLikedManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::GetWhoLiked(managedRequest, result);
	}

	DO_EXPORT(int, PrxPostPlayedWith) (PostPlayedWithManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::PostPlayedWith(managedRequest, result);
	}

	DO_EXPORT(int, PrxGetPlayedWith) (GetPlayedWithManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::GetPlayedWith(managedRequest, result);
	}

	DO_EXPORT(int, PrxGetSharedVideos) (GetSharedVideosManaged* managedRequest, APIResult* result)
	{
		return ActivityFeed::GetSharedVideos(managedRequest, result);
	}

	void GetFeedManaged::CopyTo(NpToolkit2::ActivityFeed::Request::GetFeed &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.user = user;
		destination.type = type;
		destination.offset = offset;
		destination.pageSize = pageSize;
	}

	void ButtonCaption::CopyTo(NpToolkit2::ActivityFeed::ButtonCaption &destination)
	{
		strcpy_s(destination.languageCode.code, SCE_NP_LANGUAGE_CODE_MAX_LEN + 1, languageCode);
		strcpy_s(destination.text, NpToolkit2::ActivityFeed::ButtonCaption::TEXT_MAX_LEN + 1, text);
	}

	void ActionManaged::CopyTo(NpToolkit2::ActivityFeed::Action &destination)
	{
		strcpy_s(destination.imageUrl, NpToolkit2::ActivityFeed::Action::URL_MAX_LEN + 1, imageUrl);
		strcpy_s(destination.uri, NpToolkit2::ActivityFeed::Action::URL_MAX_LEN + 1, uri);
		strcpy_s(destination.storeLabel, NpToolkit2::ActivityFeed::Action::STORE_LABEL_MAX_LEN + 1, storeLabel);

		int startGameArgumentsSize = strlen(startGameArguments);

		if (startGameArgumentsSize > 0)
		{
			destination.startGameArguments = new char[startGameArgumentsSize+1];
			strcpy_s(destination.startGameArguments, startGameArgumentsSize+1, startGameArguments);
			destination.startGameArgumentsSize = startGameArgumentsSize;
		}
		else
		{
			destination.startGameArguments = NULL;
			destination.startGameArgumentsSize = 0;
		}

		destination.storeServiceLabel = storeServiceLabel;
		destination.type = type;

		for (int i = 0; i < NpToolkit2::ActivityFeed::Action::MAX_BUTTON_CAPTIONS; i++)
		{
			buttonCaptions[i].CopyTo(destination.buttonCaptions[i]);
		}
	};

	void MediaManaged::CopyTo(NpToolkit2::ActivityFeed::Media &destination)
	{
		strcpy_s(destination.largeImageUrl, NpToolkit2::ActivityFeed::Media::URL_MAX_LEN + 1, largeImageUrl);
		strcpy_s(destination.videoUrl, NpToolkit2::ActivityFeed::Media::URL_MAX_LEN + 1, videoUrl);
	};

	void CaptionManaged::CopyTo(NpToolkit2::ActivityFeed::Caption &destination)
	{
		strcpy_s(destination.languageCode.code, SCE_NP_LANGUAGE_CODE_MAX_LEN + 1, languageCode);
		strcpy_s(destination.caption, NpToolkit2::ActivityFeed::Caption::CAPTION_MAX_LEN + 1, caption);
	};

	void PostInGameStoryManaged::CopyTo(NpToolkit2::ActivityFeed::Request::PostInGameStory &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		for (int i = 0; i < NpToolkit2::ActivityFeed::Request::PostInGameStory::MAX_ACTIONS; i++)
		{
			actions[i].CopyTo(destination.actions[i]);
		}

		media.CopyTo(destination.media);

		if (numCaptions > 0)
		{
			destination.numCaptions = numCaptions;

			destination.captions = new NpToolkit2::ActivityFeed::Caption[numCaptions];

			for (int i = 0; i < numCaptions; i++)
			{
				captions[i].CopyTo(destination.captions[i]);
			}
		}
		else
		{
			destination.captions = NULL;
			destination.numCaptions = 0;
		}

		if (numCondensedCaptions > 0)
		{
			destination.numCondensedCaptions = numCondensedCaptions;

			destination.condensedCaptions = new NpToolkit2::ActivityFeed::Caption[numCondensedCaptions];

			for (int i = 0; i < numCondensedCaptions; i++)
			{
				condensedCaptions[i].CopyTo(destination.condensedCaptions[i]);
			}
		}
		else
		{
			destination.condensedCaptions = NULL;
			destination.numCondensedCaptions = 0;
		}

		destination.subType = subType;

		strcpy_s(destination.userComment, NpToolkit2::ActivityFeed::Request::PostInGameStory::USER_COMMENT_MAX_LEN + 1, userComment);
	}

	class PostInGameStoryCleanup : public RequestCleanup<NpToolkit2::ActivityFeed::Request::PostInGameStory>
	{
	public:

		PostInGameStoryCleanup(NpToolkit2::ActivityFeed::Request::PostInGameStory* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::ActivityFeed::Request::PostInGameStory* request = GetRequest();

			if (request->captions != NULL)
			{
				delete[] request->captions;
			}

			if (request->condensedCaptions != NULL)
			{
				delete[] request->condensedCaptions;
			}

			for (int i = 0; i < NpToolkit2::ActivityFeed::Request::PostInGameStory::MAX_ACTIONS; i++)
			{
				if (request->actions[i].startGameArguments != NULL)
				{
					delete[] request->actions[i].startGameArguments;
				}
			}
		}
	};

	void StoryIdManaged::CopyTo(NpToolkit2::ActivityFeed::StoryId &destination)
	{
		strcpy_s(destination.id, NpToolkit2::ActivityFeed::StoryId::STORY_ID_LEN, id);
	}

	void SetLikedManaged::CopyTo(NpToolkit2::ActivityFeed::Request::SetLiked &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		storyId.CopyTo(destination.storyId);

		destination.isLiked = isLiked;
	}

	void GetWhoLikedManaged::CopyTo(NpToolkit2::ActivityFeed::Request::GetWhoLiked &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.lastUserRetrieved = lastUserRetrieved;

		storyId.CopyTo(destination.storyId);

		destination.pageSize = pageSize;
	}

	void PostPlayedWithManaged::CopyTo(NpToolkit2::ActivityFeed::Request::PostPlayedWith &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.numUsers = numUsers;

		for (int i = 0; i < numUsers; i++)
		{
			destination.userIds[i] = userIds[i];
		}

		strcpy_s(destination.playedWithDescription, NpToolkit2::ActivityFeed::Request::PostPlayedWith::DESCRIPTION_MAX_LEN + 1, playedWithDescription);
	}

	void GetPlayedWithManaged::CopyTo(NpToolkit2::ActivityFeed::Request::GetPlayedWith &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void GetSharedVideosManaged::CopyTo(NpToolkit2::ActivityFeed::Request::GetSharedVideos &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.user = user;
	}

	int ActivityFeed::GetFeed(GetFeedManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptFeedResponse* nptResponse = new NptFeedResponse();

		NpToolkit2::ActivityFeed::Request::GetFeed nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::getFeed(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::PostInGameStory(PostInGameStoryManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::ActivityFeed::Request::PostInGameStory* nptRequest = new NpToolkit2::ActivityFeed::Request::PostInGameStory();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::ActivityFeed::postInGameStory(*nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		PostInGameStoryCleanup* cleanup = new PostInGameStoryCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::SetLiked(SetLikedManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::ActivityFeed::Request::SetLiked nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::setLiked(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::GetWhoLiked(GetWhoLikedManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptUsersWhoLikedResponse * nptResponse = new NptUsersWhoLikedResponse();

		NpToolkit2::ActivityFeed::Request::GetWhoLiked nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::getWhoLiked(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::PostPlayedWith(PostPlayedWithManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::ActivityFeed::Request::PostPlayedWith nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::postPlayedWith(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::GetPlayedWith(GetPlayedWithManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptPlayedWithFeedResponse * nptResponse = new NptPlayedWithFeedResponse();

		NpToolkit2::ActivityFeed::Request::GetPlayedWith nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::getPlayedWith(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int ActivityFeed::GetSharedVideos(GetSharedVideosManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptSharedVideosResponse * nptResponse = new NptSharedVideosResponse();

		NpToolkit2::ActivityFeed::Request::GetSharedVideos nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::ActivityFeed::getSharedVideos(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}
	
	// Marshal responses
	void ActivityFeed::MarshalFeed(NptFeedResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::GetFeedBegin);

		const NptFeed* feed = response->get();

		UInt32 numStories = feed->numStories;

		buffer.WriteUInt32((UInt32)numStories);

		for (int i = 0; i < numStories; i++)
		{
			WriteToBuffer(feed->stories[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::GetFeedEnd);

		SUCCESS_RESULT(result);
	}

	void ActivityFeed::MarshalUsersWhoLiked(NptUsersWhoLikedResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::UsersWhoLikedBegin);

		const NptUsersWhoLiked* usersWhoLiked = response->get();

		UInt32 numUsers = usersWhoLiked->numUsers;

		buffer.WriteUInt32((UInt32)numUsers);

		for (int i = 0; i < numUsers; i++)
		{
			WriteToBuffer(usersWhoLiked->users[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::UsersWhoLikedEnd);

		SUCCESS_RESULT(result);
	}

	void ActivityFeed::MarshalPlayedWithFeed(NptPlayedWithFeedResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::PlayedWithFeedBegin);

		const NptPlayedWithFeed* playedWithFeed = response->get();

		UInt32 numStories = playedWithFeed->numStories;

		buffer.WriteUInt32((UInt32)numStories);

		for (int i = 0; i < numStories; i++)
		{
			WriteToBuffer(playedWithFeed->stories[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::PlayedWithFeedEnd);

		SUCCESS_RESULT(result);
	}

	void ActivityFeed::MarshalSharedVideos(NptSharedVideosResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::SharedVideosBegin);

		const NptSharedVideos* sharedVideos = response->get();


		UInt32 numVideos = sharedVideos->numVideos;

		buffer.WriteUInt32((UInt32)numVideos);

		for (int i = 0; i < numVideos; i++)
		{
			WriteToBuffer(sharedVideos->videos[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::SharedVideosEnd);

		SUCCESS_RESULT(result);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::Story& story, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::StoryBegin);

		buffer.WriteString(story.creationDate);
		buffer.WriteString(story.userComment);

		WriteToBuffer(story.media, buffer);
		WriteToBuffer(story.storyId, buffer);
		WriteToBuffer(story.caption, buffer);

		buffer.WriteUInt32((UInt32)story.type);	

		buffer.WriteInt32(story.subType);

		WriteToBuffer(story.postCreator, buffer);

		buffer.WriteUInt32(story.numLikes);
		buffer.WriteUInt32(story.numComments);

		buffer.WriteBool(story.isReshareable);
		buffer.WriteBool(story.isLiked);

		buffer.WriteMarker(BufferIntegrityChecks::StoryEnd);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::PlayedWithStory& story, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::StoryBegin);

		WriteToBuffer(story.storyId, buffer);

		UInt32 numUsers = story.numUsers;

		buffer.WriteUInt32((UInt32)numUsers);

		for (int i = 0; i < numUsers; i++)
		{
			WriteToBuffer(story.users[i], buffer);
		}

		buffer.WriteString(story.titleName);
		buffer.WriteString(story.date);

		Core::WriteToBuffer(story.titleId, buffer);

		buffer.WriteString(story.playedWithDescription);

		buffer.WriteMarker(BufferIntegrityChecks::StoryEnd);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::SharedVideo& video, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::SharedVideoBegin);

		WriteToBuffer(video.storyId, buffer);
		WriteToBuffer(video.caption, buffer);
		WriteToBuffer(video.sourceCreator, buffer);

		buffer.WriteString(video.snType);
		buffer.WriteString(video.videoId);
		buffer.WriteString(video.creationDate);
		buffer.WriteString(video.videoDuration);
		buffer.WriteString(video.comment);

		buffer.WriteMarker(BufferIntegrityChecks::SharedVideoEnd);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::StoryId& storyId, MemoryBuffer& buffer)
	{
		buffer.WriteString(storyId.id);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::StoryUser& storyUser, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::StoryUserBegin);

		Core::WriteToBuffer(storyUser.user, buffer);

		buffer.WriteString(storyUser.avatarUrl);

		Profile::WriteToBuffer(storyUser.realName, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::StoryUserEnd);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::Media& media, MemoryBuffer& buffer)
	{
		buffer.WriteString(media.largeImageUrl);
		buffer.WriteString(media.videoUrl);
	}

	void ActivityFeed::WriteToBuffer(const NpToolkit2::ActivityFeed::Caption& caption, MemoryBuffer& buffer)
	{
		buffer.WriteString(caption.languageCode.code);
		buffer.WriteString(caption.caption);
	}

}
