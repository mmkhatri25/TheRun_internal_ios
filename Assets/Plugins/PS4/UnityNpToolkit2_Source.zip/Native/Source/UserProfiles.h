#pragma once

#include "../Includes/PluginCommonIncludes.h"
#include "../Source/Core.h"

namespace NPT
{
	struct LocalLoginUserId
	{
		SceUserServiceUserId userId;
		SceNpAccountId accountId;
		Int32 sceErrorCode;
	};

	class GetNpProfilesManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId accountIds[NpToolkit2::UserProfile::Request::GetNpProfiles::SIZE_ACCOUNT_IDS];	///< A list of users to retrieve profile information from
		UInt32 numValidAccountIds;						///< The number of valid account Ids provided in the array. They must be consecutive and start from the beginning of the array

		void CopyTo(NpToolkit2::UserProfile::Request::GetNpProfiles &destination);
	};

	class GetVerifiedAccountsForTitleManaged : public RequestBaseManaged
	{
	public:
		UInt32 limit;						///< The maximum number of profiles from Verified Accounts to retrieve. Defaults to <c>10</c>    

		void CopyTo(NpToolkit2::UserProfile::Request::GetVerifiedAccountsForTitle &destination);
	};

	class DisplayUserProfileDialogManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId	targetAccountId;		///< The user profile dialog will be opened for this account

		void CopyTo(NpToolkit2::UserProfile::Request::DisplayUserProfileDialog &destination);
	};

	class DisplayGriefReportingDialogManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId	targetAccountId;	///< The grief reporting dialog will be opened to report this account
		bool reportOnlineId;				///< <c>true</c> when the Online Id should be reported
		bool reportName;					///< <c>true</c> when the Name should be reported
		bool reportPicture;					///< <c>true</c> when the Picture of the profile should be reported
		bool reportAboutMe;					///< <c>true</c> when the About Me section of the profile should be reported

		void CopyTo(NpToolkit2::UserProfile::Request::DisplayGriefReportingDialog &destination);
	};

	class UserProfiles
	{
	private:

	public:

		typedef NpToolkit2::UserProfile::NpProfiles NptProfiles;
		typedef NpToolkit2::Core::Response<NpToolkit2::UserProfile::NpProfiles> NptProfilesResponse;

		static void GetLocalLoginUserIds(LocalLoginUserId* userIds, Int32 maxSize, APIResult* result);

		// Requests
		static int GetNpProfiles(GetNpProfilesManaged* managedRequest, APIResult* result);
		static int GetVerifiedAccountsForTitle(GetVerifiedAccountsForTitleManaged* managedRequest, APIResult* result);

		// Dialogs
		static int DisplayUserProfileDialog(DisplayUserProfileDialogManaged* managedRequest, APIResult* result);
		static int DisplayGriefReportingDialog(DisplayGriefReportingDialogManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalNpProfiles(NptProfilesResponse* response, MemoryBuffer& buffer, APIResult* result);
	private:

	};
}





