#pragma once

#include "../Includes/PluginCommonIncludes.h"
#include "Core.h"

namespace NPT
{
	class SetScoreManaged : public RequestBaseManaged
	{
	public:
		SceNpScoreValue score;			///< The score to register
		char utf8Comment[SCE_NP_SCORE_COMMENT_MAXLEN+1];  // ///< Optional. A string comment to be registered along with the score                                          

		UInt8 data[SCE_NP_SCORE_GAMEINFO_MAXSIZE];  ///< Optional. Game information data that can be saved per score
		UInt64 dataLength;			///< Size of the data.

		SceNpScoreBoardId boardId;             ///< The board Id of the board where the score will be registered
		SceNpScorePcId pcId;                ///< Optional. The player character Id, in case it is different than 0           

		void CopyTo(NpToolkit2::Ranking::Request::SetScore &destination);
	};

	class GetRangeOfRanksManaged : public RequestBaseManaged
	{
	public:

		SceNpScoreBoardId boardId;				///< The board Id of the board where the range of ranks will be obtained from                                             
		SceNpScoreRankNumber startRank;			///< The first rank that will be obtained in the range
		UInt32 range;							///< The number of ranks that will be obtained, starting from the <i><c>startRank</c></i>
		bool isCrossSaveInformation;			///< Optional. Set it to <c>true</c> if the board is shared with PS Vita or PS3 applications                       

		void CopyTo(NpToolkit2::Ranking::Request::GetRangeOfRanks &destination);
	};

	class GetFriendsRanksManaged : public RequestBaseManaged
	{
	public:

		SceNpScoreBoardId boardId;		///< The board Id of the board where the friends ranks will be obtained from                                            
		UInt32 startRank;				///< Optional. In case pagination is needed, specify the last rank obtained in the previous call. Otherwise, leave blank        
		SceNpScorePcId friendsWithPcId; ///< Optional. In case the pc Id to be retrieved is different than the default one <c>0</c>, specify the pc Id to retrieve
		bool isCrossSaveInformation;	///< Optional. Set it to <c>true</c> if the board is shared with PS Vita or PS3 applications                                
		bool addCallingUserRank;		///< True by default. It also returns the calling user rank, along with the ranks of the user' friends     

		void CopyTo(NpToolkit2::Ranking::Request::GetFriendsRanks &destination);
	};

	struct ScoreAccountIdPcIdManaged
	{
		SceNpAccountId accountId;
		SceNpScorePcId pcId;
	};

	class GetUsersRanksManaged : public RequestBaseManaged
	{
	public:

		ScoreAccountIdPcIdManaged users[NpToolkit2::Ranking::Request::GetUsersRanks::MAX_NUM_USERS];	///< The array identifying the users whom ranks want to be obtained. It makes a deep copy inside the request using internal memory, so it does not need to be persistent. If pc ids should be looked into, set <i><c>ignorePcIds</c></i> to <c>false</c>. Otherwise, do not set <i><c>pcIds</c></i>                                
		UInt32 numUsers;					///< The size of the <i><c>users</c></i> array
		SceNpScoreBoardId boardId;			///< The board Id of the board where the users ranks will be obtained from                                          
		bool isCrossSaveInformation;		///< Optional. Set it to <c>true</c> if the board is shared with PS Vita or PS3 applications                                
		bool ignorePcIds;					///< Optional. When set to <c>true</c>, the pc Ids specified in the <i><c>users</c></i> array won't be ignored          

		void CopyTo(NpToolkit2::Ranking::Request::GetUsersRanks &destination);
	};

	class SetGameDataManaged : public RequestBaseManaged
	{
	public:

		SceNpScoreBoardId boardId;	///< The board Id of the board where the game data will be set
		Int32 idOfPrevChunk;		///< Set it when sending game data in chunks, after the first chunk has been sent. The value should be the value received in <i><c>SetGameDataResult.chunkId</c></i> in the response of the previous request                                         
		SceNpScoreValue score;		///< The score to save the game data that is being send. This score must belong to the calling user (only the calling user game data can be set)                                       
		UInt64 totalSize;			///< The total size of the entire game data. All chunks included
		void *data;			        ///< Pointer to the game data to be sent in this call. It needs to remain valid in memory until the operation completes, as the library won't make an internal copy of it       
		UInt64 byteOffset;          // The byte offset from the start of data to send.
		UInt64 chunkDataSize;		///< The size of the <i><c>chunkData</c></i> buffer
		SceNpScorePcId	pcId;		///< Optional. The player character Id, in case it is different than 0         

		void CopyTo(NpToolkit2::Ranking::Request::SetGameData &destination);
	};

	class GetGameDataManaged : public RequestBaseManaged
	{
	public:

		SceNpScoreBoardId boardId;		///< The board Id of the board where the game data will be get from                                                     
		Int32 idOfPrevChunk;			///< Set it when getting game data in chunks, after the first chunk has been received. The value should be the value received in <i><c>GetGameDataResult.chunkId</c></i> in the response of the previous request                          
		SceNpAccountId accountId;		///< The account Id of the user to get the game data from
		void *chunkToRcvData;			///< Pointer to a space in memory to received the game data requested. It needs to remain valid in memory until the operation completes, as the library won't make an internal copy of it                                                
		UInt64 byteOffset;      //The byte offset from the start of data to send.
		UInt64 chunkToRcvDataSize;		///< The size of the <i><c>chunkToRcvData</c></i> buffer
		SceNpScorePcId	pcId;			///< Optional. The player character Id, in case it is different than <c>0</c>     

		void CopyTo(NpToolkit2::Ranking::Request::GetGameData &destination);
	};

	// Provide Ranking PRX calls to NpToolkit Ranking methods
	class Ranking
	{
	private:

	public:

		typedef NpToolkit2::Ranking::TempRank NptTempRank;
		typedef NpToolkit2::Core::Response<NptTempRank> NptTempRankResponse;

		typedef NpToolkit2::Ranking::RangeOfRanks NptRangeOfRanks;
		typedef NpToolkit2::Core::Response<NptRangeOfRanks> NptRangeOfRanksResponse;

		typedef NpToolkit2::Ranking::FriendsRanks NptFriendsRanks;
		typedef NpToolkit2::Core::Response<NptFriendsRanks> NptFriendsRanksResponse;

		typedef NpToolkit2::Ranking::UsersRanks NptUsersRanks;
		typedef NpToolkit2::Core::Response<NptUsersRanks> NptUsersRanksResponse;

		typedef NpToolkit2::Ranking::SetGameDataResult NptSetGameDataResult;
		typedef NpToolkit2::Core::Response<NptSetGameDataResult> NptSetGameDataResultResponse;

		typedef NpToolkit2::Ranking::GetGameDataResult NptGetGameDataResult;
		typedef NpToolkit2::Core::Response<NptGetGameDataResult> NptGetGameDataResultResponse;

		// Requests
		static int SetScore(SetScoreManaged* managedRequest, APIResult* result);
		static int GetRangeOfRanks(GetRangeOfRanksManaged* managedRequest, APIResult* result);
		static int GetFriendsRanks(GetFriendsRanksManaged* managedRequest, APIResult* result);
		static int GetUsersRanks(GetUsersRanksManaged* managedRequest, APIResult* result);
		static int SetGameData(SetGameDataManaged* managedRequest, APIResult* result);
		static int GetGameData(GetGameDataManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalTempRank(NptTempRankResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalRangeOfRanks(NptRangeOfRanksResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalFriendsRanks(NptFriendsRanksResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalUsersRanks(NptUsersRanksResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalSetGameDataResult(NptSetGameDataResultResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalGetGameDataResult(NptGetGameDataResultResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Write Methods
		static void WriteToBuffer(const SceNpScorePlayerRankDataA& sceNpScorePlayerRankData, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpScorePlayerRankDataForCrossSave& sceNpScorePlayerRankDataForCrossSave, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpScoreRankDataA& sceNpScoreRankDataA, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpScoreRankDataForCrossSave& sceNpScoreRankDataForCrossSave, MemoryBuffer& buffer);

	private:

	};
}





