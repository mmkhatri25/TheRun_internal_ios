
#include "Messaging.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxSendInGameMessage ) (SendInGameMessageManaged* managedRequest, APIResult* result)
	{
		return Messaging::SendInGameMessage(managedRequest, result);
	}

	void SendInGameMessageManaged::CopyTo(NpToolkit2::Messaging::Request::SendInGameMessage &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.message.dataSize = messageSize;
		memcpy_s(destination.message.data, SCE_NP_IN_GAME_MESSAGE_DATA_SIZE_MAX, message, messageSize);

		destination.recipientId = recipientId;
		destination.recipientPlatformType = recipientPlatformType;
	}

	int Messaging::SendInGameMessage(SendInGameMessageManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Messaging::Request::SendInGameMessage nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::sendInGameMessage(nptRequest, nptResponse);

		if (ret < 0)
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Notification
	void Messaging::MarshalNewInGameMessage(NptNewInGameMessageResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NewInGameMessageBegin);

		const NptNewInGameMessage* newInGameMessage = response->get();

		buffer.WriteData(newInGameMessage->message.data, newInGameMessage->message.dataSize);

		Core::WriteToBuffer(newInGameMessage->sender, buffer);
		Core::WriteToBuffer(newInGameMessage->recipient, buffer);

		buffer.WriteUInt32((UInt32)newInGameMessage->senderPlatformType);
		buffer.WriteUInt32((UInt32)newInGameMessage->recipientPlatformType);

		buffer.WriteMarker(BufferIntegrityChecks::NewInGameMessageEnd);

		SUCCESS_RESULT(result);
	}

	void Messaging::HandleGameCustomDataEvent(SceNpGameCustomDataEventParam* eventParam)
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::GameCustomDataEventBegin);

		buffer.WriteUInt64(eventParam->itemId);
		Core::WriteToBuffer(eventParam->onlineId, buffer);
		buffer.WriteInt32(eventParam->userId);

		buffer.WriteMarker(BufferIntegrityChecks::GameCustomDataEventEnd);

		buffer.FinishResponseWrite();

		CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended::notificationGameCustomDataEvent, buffer);
	}

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
	DO_EXPORT( int, PrxDisplayReceivedGameDataMessagesDialog ) (DisplayReceivedGameDataMessagesDialogManaged* managedRequest, APIResult* result)
	{
		return Messaging::DisplayReceivedGameDataMessagesDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxSendGameDataMessage ) (SendGameDataMessageManaged* managedRequest, APIResult* result)
	{
		return Messaging::SendGameDataMessage(managedRequest, result);
	}

	DO_EXPORT( int, PrxConsumeGameDataMessage ) (ConsumeGameDataMessageManaged* managedRequest, APIResult* result)
	{
		return Messaging::ConsumeGameDataMessage(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetReceivedGameDataMessages ) (GetReceivedGameDataMessagesManaged* managedRequest, APIResult* result)
	{
		return Messaging::GetReceivedGameDataMessages(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetGameDataMessageThumbnail ) (GetGameDataMessageThumbnailManaged* managedRequest, APIResult* result)
	{
		return Messaging::GetGameDataMessageThumbnail(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetGameDataMessageAttachment ) (GetGameDataMessageAttachmentManaged* managedRequest, APIResult* result)
	{
		return Messaging::GetGameDataMessageAttachment(managedRequest, result);
	}



	void DisplayReceivedGameDataMessagesDialogManaged::CopyTo(NpToolkit2::Messaging::Request::DisplayReceivedGameDataMessagesDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
		
	}

	void GameDataMessageImageManaged::CopyTo(NpToolkit2::Messaging::Request::GameDataMessageImage &destination)
	{
		strcpy_s(destination.imgPath, NpToolkit2::Messaging::Request::GameDataMessageImage::IMAGE_PATH_MAX_LEN + 1, imgPath);
	}

	void LocalizedMetadataManaged::CopyTo(NpToolkit2::Messaging::Request::LocalizedMetadata &destination)
	{
		strcpy_s(destination.npLanguage.code, SCE_NP_LANGUAGE_CODE_MAX_LEN + 1, languageCode);
		strcpy_s(destination.name, NpToolkit2::Messaging::Request::LocalizedMetadata::MAX_SIZE_DATA_NAME + 1, name);
		strcpy_s(destination.description, NpToolkit2::Messaging::Request::LocalizedMetadata::MAX_SIZE_DATA_DESCRIPTION + 1, name);
	}

	void SendGameDataMessageManaged::CopyTo(NpToolkit2::Messaging::Request::SendGameDataMessage &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
		
		strcpy_s(destination.textMessage, NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_TEXT_MESSAGE+1, textMessage); 
		strcpy_s(destination.dataName, NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_DATA_NAME+1, dataName); 
		strcpy_s(destination.dataDescription, NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_DATA_DESCRIPTION+1, dataDescription); 

		for(int i = 0; i < numRecipients; i++)
		{
			destination.recipients[i] = recipients[i];
		}

		destination.type = type;
		destination.expireMinutes = expireMinutes;

		destination.attachment = new UInt8[attachmentSize];
		memcpy(destination.attachment, attachment, attachmentSize); 
		destination.attachmentSize = attachmentSize;

		strcpy_s(destination.url, NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_URL_SIZE+1, url); 

		if ( numDataLocalized > 0 )
		{
			destination.dataLocalized = new NpToolkit2::Messaging::Request::LocalizedMetadata[numDataLocalized];

			for(int i = 0; i < numDataLocalized; i++)
			{
				dataLocalized[i].CopyTo(destination.dataLocalized[i]);
			}
		}

		thumbnail.CopyTo(destination.thumbnail);

		destination.maxNumberRecipientsToAdd = maxNumberRecipientsToAdd;
		destination.enableDialog = enableDialog;
		destination.senderCanEditRecipients = senderCanEditRecipients;
		destination.isPS4Available = isPS4Available;
		destination.isPSVitaAvailable = isPSVitaAvailable;
		destination.addGameDataMsgIdToUrl = addGameDataMsgIdToUrl;
	}

	class SendGameDataMessageCleanup : public RequestCleanup<NpToolkit2::Messaging::Request::SendGameDataMessage>
	{
	public:

		SendGameDataMessageCleanup(NpToolkit2::Messaging::Request::SendGameDataMessage* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Messaging::Request::SendGameDataMessage* request = GetRequest();

			if ( request->attachment != NULL )
			{
				delete[] (UInt8*)request->attachment;
			}

			if ( request->dataLocalized != NULL )
			{
				delete[] request->dataLocalized;
			}
		}
	};

	void ConsumeGameDataMessageManaged::CopyTo(NpToolkit2::Messaging::Request::ConsumeGameDataMessage &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
		
		destination.gameDataMsgId = gameDataMsgId;
	}

	void GetReceivedGameDataMessagesManaged::CopyTo(NpToolkit2::Messaging::Request::GetReceivedGameDataMessages &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
		
		for(int i = 0; i < numGameDataMsgIds; i++)
		{
			destination.gameDataMsgIds[i] = gameDataMsgIds[i];
		}

		destination.pageSize = pageSize;
		destination.offset = offset;
		destination.type = type;
	}

	void GetGameDataMessageThumbnailManaged::CopyTo(NpToolkit2::Messaging::Request::GetGameDataMessageThumbnail &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	
		destination.gameDataMsgId = gameDataMsgId;
	}

	void GetGameDataMessageAttachmentManaged::CopyTo(NpToolkit2::Messaging::Request::GetGameDataMessageAttachment &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
		
		destination.gameDataMsgId = gameDataMsgId;
	}

	
	int Messaging::DisplayReceivedGameDataMessagesDialog(DisplayReceivedGameDataMessagesDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Messaging::Request::DisplayReceivedGameDataMessagesDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::displayReceivedGameDataMessagesDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Messaging::SendGameDataMessage(SendGameDataMessageManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Messaging::Request::SendGameDataMessage* nptRequest = new NpToolkit2::Messaging::Request::SendGameDataMessage();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Messaging::sendGameDataMessage(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		SendGameDataMessageCleanup* cleanup = new SendGameDataMessageCleanup(nptRequest);
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Messaging::ConsumeGameDataMessage(ConsumeGameDataMessageManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Messaging::Request::ConsumeGameDataMessage nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::consumeGameDataMessage(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Messaging::GetReceivedGameDataMessages(GetReceivedGameDataMessagesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptGameDataMessagesResponse * nptResponse = new NptGameDataMessagesResponse();

		NpToolkit2::Messaging::Request::GetReceivedGameDataMessages nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::getReceivedGameDataMessages(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Messaging::GetGameDataMessageThumbnail(GetGameDataMessageThumbnailManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptGameDataMessageThumbnailResponse * nptResponse = new NptGameDataMessageThumbnailResponse();

		NpToolkit2::Messaging::Request::GetGameDataMessageThumbnail nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::getGameDataMessageThumbnail(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Messaging::GetGameDataMessageAttachment(GetGameDataMessageAttachmentManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptGameDataMessageAttachmentResponse * nptResponse = new NptGameDataMessageAttachmentResponse();

		NpToolkit2::Messaging::Request::GetGameDataMessageAttachment nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Messaging::getGameDataMessageAttachment(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Marshal responses
	void Messaging::MarshalGameDataMessages(NptGameDataMessagesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessagesBegin);

		const NptGameDataMessages* gameDataMessages = response->get();

		buffer.WriteUInt64(gameDataMessages->numGameDataMessages);

		for(int i = 0; i < gameDataMessages->numGameDataMessages; i++)
		{
			WriteToBuffer(gameDataMessages->gameDataMessages[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessagesEnd);

		SUCCESS_RESULT(result);
	}

	void Messaging::MarshalGameDataMessageThumbnail(NptGameDataMessageThumbnailResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageThumbnailBegin);

		const NptGameDataMessageThumbnail* gameDataMessageThumbnail = response->get();

		buffer.WriteUInt64(gameDataMessageThumbnail->gameDataMsgId);

		buffer.WriteData((char*)gameDataMessageThumbnail->thumbnail,gameDataMessageThumbnail->thumbnailSize);

		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageThumbnailEnd);

		SUCCESS_RESULT(result);
	}

	void Messaging::MarshalGameDataMessageAttachment(NptGameDataMessageAttachmentResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageAttachmentBegin);

		const NptGameDataMessageAttachment* gameDataMessageAttachment = response->get();

		buffer.WriteUInt64(gameDataMessageAttachment->gameDataMsgId);

		buffer.WriteData((char*)gameDataMessageAttachment->attachment,gameDataMessageAttachment->attachmentSize);

		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageAttachmentEnd);

		SUCCESS_RESULT(result);
	}

	void Messaging::MarshalNewGameDataMessage(NptNewGameDataMessageResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NewGameDataMessageBegin);

		const NptNewGameDataMessage* newGameDataMessage = response->get();

		Core::WriteToBuffer(newGameDataMessage->to, buffer);
		Core::WriteToBuffer(newGameDataMessage->from, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::NewGameDataMessageEnd);

		SUCCESS_RESULT(result);
	}

	// Write Methods
	void Messaging::WriteToBuffer(const NpToolkit2::Messaging::GameDataMessage& gameDataMessage, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageBegin);

		buffer.WriteUInt64(gameDataMessage.gameDataMsgId);

		Core::WriteToBuffer(gameDataMessage.fromUser, buffer);

		buffer.WriteString(gameDataMessage.receivedDate);
		buffer.WriteString(gameDataMessage.expiredDate);

		buffer.WriteBool(gameDataMessage.isPS4Available);
		buffer.WriteBool(gameDataMessage.isPSVitaAvailable);

		buffer.WriteUInt32((UInt32)gameDataMessage.type);

		buffer.WriteString(gameDataMessage.url);

		buffer.WriteBool(gameDataMessage.hasDetails);

		if ( gameDataMessage.hasDetails == true )
		{
			WriteToBuffer(gameDataMessage.details, buffer);
		}

		buffer.WriteBool(gameDataMessage.isUsed);

		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageEnd);
	}

	void Messaging::WriteToBuffer(const NpToolkit2::Messaging::GameDataMessageDetails& gmeDataMessageDetails, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageDetailsBegin);

		buffer.WriteString(gmeDataMessageDetails.dataName);
		buffer.WriteString(gmeDataMessageDetails.dataDescription);
		buffer.WriteString(gmeDataMessageDetails.textMessage);

		buffer.WriteMarker(BufferIntegrityChecks::GameDataMessageDetailsEnd);
	}
#endif
}
