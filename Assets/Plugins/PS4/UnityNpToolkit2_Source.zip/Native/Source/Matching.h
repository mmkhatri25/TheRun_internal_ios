#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{

	struct AttributeMetadataManaged
	{
		char name[NpToolkit2::Matching::AttributeMetadata::MAX_SIZE_NAME + 1];	

		NpToolkit2::Matching::AttributeType type;										
		NpToolkit2::Matching::AttributeScope scope;							
		NpToolkit2::Matching::RoomAttributeVisibility roomAttributeVisibility;

		UInt32 size;	

		void CopyTo(NpToolkit2::Matching::AttributeMetadata &destination);
	};

	struct AttributeManaged
	{
		AttributeMetadataManaged metadata;
		int intValue;	
		char binValue[NpToolkit2::Matching::Attribute::MAX_SIZE_BIN_VALUE];	

		void CopyTo(NpToolkit2::Matching::Attribute &destination);
	};

	struct SessionImageManaged
	{
		char sessionImgPath[NpToolkit2::Session::SessionImage::IMAGE_PATH_MAX_LEN + 1];

		void CopyTo(NpToolkit2::Session::SessionImage &destination);
	};

	struct LocalizedSessionInfoManaged
	{
		char				sessionName[NpToolkit2::Session::LocalizedSessionInfo::SESSION_NAME_LEN + 1];	
		char				status[NpToolkit2::Session::LocalizedSessionInfo::STATUS_LEN + 1];				
		char				languageCode[SCE_NP_LANGUAGE_CODE_MAX_LEN + 1];	// 5 char code, with null terminator

		void CopyTo(NpToolkit2::Matching::LocalizedSystemInfo &destination);
	};

	struct MatchingPresenceOptionDataManaged   // SceNpMatching2PresenceOptionData
	{
		char data[SCE_NP_MATCHING2_PRESENCE_OPTION_DATA_SIZE];
		UInt8 length;  // Maximum length of SCE_NP_MATCHING2_PRESENCE_OPTION_DATA_SIZE is currently only 16, so a byte is large enough to contain the size

		void CopyTo(SceNpMatching2PresenceOptionData &destination);
	};

	struct SessionIdManaged
	{
		char data[SCE_NP_SESSION_ID_MAX_SIZE+1];

		void CopyTo(SceNpSessionId &destination);
	};

	// Requests
	class SetInitConfigurationManaged : public RequestBaseManaged
	{
	public:
		const static int32_t MAX_ATTRIBUTES = 64;

		UInt64 numAttributes;
		AttributeMetadataManaged attributes[MAX_ATTRIBUTES];

		void CopyTo(NpToolkit2::Matching::Request::SetInitConfiguration &destination);
	};	

	class GetWorldsManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::Matching::Request::GetWorlds &destination);
	};	

	class CreateRoomManaged : public RequestBaseManaged
	{
	public:
		const static int32_t MAX_ATTRIBUTES = 64;

		UInt64 numAttributes;
		AttributeManaged attributes[MAX_ATTRIBUTES];

		char name[NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_ROOM_NAME + 1];
		char password[SCE_NP_MATCHING2_SESSION_PASSWORD_SIZE];

		NpToolkit2::Matching::RoomVisibility visibility;				
		UInt32 numReservedSlots;

		UInt64 fixedDataSize;
		void *fixedData;		

		UInt64 changeableDataSize;
		void *changeableData;		

		char status[NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_ROOM_STATUS + 1];

		LocalizedSessionInfoManaged	localizations[NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_LOCALIZATIONS];
		
		SessionImageManaged image;

		NpToolkit2::Matching::RoomMigrationType ownershipMigration;	
		NpToolkit2::Matching::TopologyType topology;
		UInt32 maxNumMembers;				
		SceNpMatching2WorldNumber worldNumber;

		bool displayOnSystem;
		bool isSystemJoinable;	
		bool joinAllLocalUsers;	
		bool isNatRestricted;
		bool isCrossplatform;
		bool allowBlockedUsersOfOwner;
		bool allowBlockedUsersOfMembers;

		void CopyTo(NpToolkit2::Matching::Request::CreateRoom &destination);
	};	

	class LeaveRoomManaged : public RequestBaseManaged
	{
	public:

		UInt64 roomId;
		MatchingPresenceOptionDataManaged notificationDataToMembers;

		void CopyTo(NpToolkit2::Matching::Request::LeaveRoom &destination);
	};

	class SearchClauseManaged
	{
	public:
		AttributeManaged attributeToCompare;
		NpToolkit2::Matching::Request::SearchOperatorType operatorType;

		void CopyTo(NpToolkit2::Matching::Request::SearchClause &destination);
	};

	class SearchRoomsManaged : public RequestBaseManaged
	{
	public:
		const static int32_t MAX_SEARCH_CLAUSES = 64;
        const static int32_t MAX_NUM_USERS_TO_SEARCH_IN_ROOMS = 20;

		UInt64 numSearchClauses;
		SearchClauseManaged searchClauses[MAX_SEARCH_CLAUSES];
		
		UInt64 numUsersToSearchInRooms;	
		SceNpAccountId usersToSearchInRooms[MAX_NUM_USERS_TO_SEARCH_IN_ROOMS]; // NpToolkit2::Matching::Request::SearchRooms::MAX_NUM_USERS_TO_SEARCH_IN_ROOMS	

		Int32 offset;	
		Int32 pageSize;

		NpToolkit2::Matching::Request::RoomsSearchScope searchScope;			
		SceNpMatching2WorldNumber worldNumber;

		bool provideRandomRooms;
		bool quickJoin;
		bool applyNatTypeFilter;
					
		void CopyTo(NpToolkit2::Matching::Request::SearchRooms &destination);
	};

	class JoinRoomManaged : public RequestBaseManaged
	{
	public:
		const static int32_t MAX_ATTRIBUTES = 64;

		char password[SCE_NP_MATCHING2_SESSION_PASSWORD_SIZE];

		UInt64 numMemberAttributes;
		AttributeManaged memberAttributes[MAX_ATTRIBUTES];

		MatchingPresenceOptionDataManaged notificationDataToMembers;

		UInt64 roomId;

		SessionIdManaged boundSessionId;

		NpToolkit2::Matching::Request::RoomJoiningType identifyRoomBy;

		bool joinAllLocalUsers;
		bool allowBlockedUsers;

		void CopyTo(NpToolkit2::Matching::Request::JoinRoom &destination);
	};

	class GetRoomPingTimeManaged : public RequestBaseManaged
	{
	public:

		UInt64 roomId;

		void CopyTo(NpToolkit2::Matching::Request::GetRoomPingTime &destination);
	};

	class SendInvitationManaged : public RequestBaseManaged
	{
	public:

		UInt64 roomId;						

		UInt64 numRecipients;
		SceNpAccountId	recipients[NpToolkit2::Matching::Request::SendInvitation::MAX_NUM_RECIPIENTS];

		char userMessage[NpToolkit2::Matching::Request::SendInvitation::MAX_SIZE_USER_MESSAGE + 1];

		UInt64 attachmentSize;
		void *attachment;

		Int32 maxNumberRecipientsToAdd;
		bool recipientsEditableByUser;
		bool enableDialog;			

		void CopyTo(NpToolkit2::Matching::Request::SendInvitation &destination);
	};

	class KickOutRoomMemberManaged : public RequestBaseManaged
	{
	public:

		UInt64 roomId;
		MatchingPresenceOptionDataManaged notificationDataToMembers;
		UInt16 memberId;
		bool allowRejoin;

		void CopyTo(NpToolkit2::Matching::Request::KickOutRoomMember &destination);
	};

	class SendRoomMessageManaged : public RequestBaseManaged
	{
	public:
		const static int32_t MAX_MEMBERS = 32;

		UInt64 roomId;

		UInt64 numMembers;
		UInt16 members[MAX_MEMBERS];

		UInt64 dataSize;
		char data[NpToolkit2::Matching::Request::SendRoomMessage::MESSAGE_MAX_SIZE + 1];

		bool isChatMsg;

		void CopyTo(NpToolkit2::Matching::Request::SendRoomMessage &destination);
	};

	class GetAttributesManaged : public RequestBaseManaged
	{
	public:

		UInt64 roomId;
		NpToolkit2::Matching::AttributeScope scope;
		NpToolkit2::Matching::RoomAttributeVisibility roomAttributeVisibility;
		UInt16 memberId;

		void CopyTo(NpToolkit2::Matching::Request::GetAttributes &destination);
	};

	class GetDataManaged : public RequestBaseManaged
	{
	public:
		UInt64 roomId;
		NpToolkit2::Matching::DataType type;

		void CopyTo(NpToolkit2::Matching::Request::GetData &destination);
	};

	class SetRoomInfoManaged : public RequestBaseManaged
	{
	public:

		// * Member attributes:
		//     * The sum of all member attributes has to be a max of 64 bytes.
		//     * Integer attributes are 8 bytes.
		const static int32_t MAX_MEMBER_ATTRIBUTES = 8;  // Could still be only 1 binary attribute that is 64 bytes in size, but this should be validated in the C# code
		const static int32_t MAX_ATTRIBUTES = 64;

		struct MemberInfo
		{
			UInt64 numMemberAttributes;
			AttributeManaged memberAttributes[MAX_MEMBER_ATTRIBUTES];		
			SceNpMatching2RoomMemberId memberId;
		};

		struct RoomExternalInfo
		{
			UInt64 numExternalAttributes;
			AttributeManaged externalAttributes[MAX_ATTRIBUTES];
			UInt64 numSearchAttributes;
			AttributeManaged searchAttributes[MAX_ATTRIBUTES];
		};

		struct RoomInternalInfo
		{
			UInt64 numInternalAttributes;
			AttributeManaged internalAttributes[MAX_ATTRIBUTES];
			NpToolkit2::Core::OptionalBoolean allowBlockedUsersOfMembers;
			NpToolkit2::Core::OptionalBoolean joinAllLocalUsers;
			NpToolkit2::Core::OptionalBoolean isNatRestricted;
			UInt32 numReservedSlots;
			NpToolkit2::Matching::RoomVisibility visibility;
			NpToolkit2::Core::OptionalBoolean closeRoom;
		};

		struct RoomSessionInfo
		{
			NpToolkit2::Core::OptionalBoolean displayOnSystem;
			NpToolkit2::Core::OptionalBoolean isSystemJoinable;
			UInt64 changeableDataSize;
			void *changeableData;
			char status[NpToolkit2::Matching::Request::SetRoomInfo::MAX_SIZE_ROOM_STATUS + 1];
			UInt64 numLocalizations;
			LocalizedSessionInfoManaged localizations[NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_LOCALIZATIONS];
			SessionImageManaged image;
		};		

		UInt64 roomId;
		NpToolkit2::Matching::Request::SetRoomInfoType roomInfoType;

		MemberInfo memberInfo;
		RoomExternalInfo roomExternalInfo;
		RoomInternalInfo roomInternalInfo;
		RoomSessionInfo roomSessionInfo;
		NpToolkit2::Matching::TopologyType roomTopology;
	
		void CopyTo(NpToolkit2::Matching::Request::SetRoomInfo &destination);
	};

	class SetMembersAsRecentlyMetManaged : public RequestBaseManaged
	{
	public:
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)

		UInt64 numMembers;		
		UInt16 members[NpToolkit2::Matching::Request::SetMembersAsRecentlyMet::NUM_RECENTLY_MET_MAX_LEN];
		UInt64 roomId;																		
		char text[NpToolkit2::Matching::Request::SetMembersAsRecentlyMet::TEXT_MAX_LEN + 1];

		void CopyTo(NpToolkit2::Matching::Request::SetMembersAsRecentlyMet &destination);
#endif
	};

	class Matching
	{
	public:

		typedef NpToolkit2::Matching::Worlds NptWorlds;
		typedef NpToolkit2::Core::Response<NptWorlds> NptWorldsResponse;

		typedef NpToolkit2::Matching::Room NptRoom;
		typedef NpToolkit2::Core::Response<NptRoom> NptRoomResponse;   // Used in both Create and Join room requests

		typedef NpToolkit2::Matching::Rooms NptRooms;
		typedef NpToolkit2::Core::Response<NptRooms> NptSearchRoomsResponse;

		typedef NpToolkit2::Matching::RoomPingTime NptRoomPingTime;
		typedef NpToolkit2::Core::Response<NptRoomPingTime> NptRoomPingTimeResponse;
		
		typedef NpToolkit2::Matching::Data NptGetData;
		typedef NpToolkit2::Core::Response<NptGetData> NptGetDataResponse;

		typedef NpToolkit2::Matching::Notification::RefreshRoom NptRefreshRoom;
		typedef NpToolkit2::Core::Response<NptRefreshRoom> NptRefreshRoomResponse;

		typedef NpToolkit2::Session::Notification::InvitationReceived NptInvitationReceived;
		typedef NpToolkit2::Core::Response<NptInvitationReceived> NptInvitationReceivedResponse;

		typedef NpToolkit2::Matching::Notification::NewRoomMessage NptNewRoomMessage;
		typedef NpToolkit2::Core::Response<NptNewRoomMessage> NptNewRoomMessageResponse;

		//Requests
		static int SetInitConfiguration(SetInitConfigurationManaged* managedRequest, APIResult* result);
		static int GetWorlds(GetWorldsManaged* managedRequest, APIResult* result);
		static int CreateRoom(CreateRoomManaged* managedRequest, APIResult* result);
		static int LeaveRoom(LeaveRoomManaged* managedRequest, APIResult* result);
		static int SearchRooms(SearchRoomsManaged* managedRequest, APIResult* result);
		static int JoinRoom(JoinRoomManaged* managedRequest, APIResult* result);
		static int GetRoomPingTime(GetRoomPingTimeManaged* managedRequest, APIResult* result);
		static int KickOutRoomMember(KickOutRoomMemberManaged* managedRequest, APIResult* result);
		static int SendRoomMessage(SendRoomMessageManaged* managedRequest, APIResult* result);
		static int GetAttributes(GetAttributesManaged* managedRequest, APIResult* result);
		static int SetRoomInfo(SetRoomInfoManaged* managedRequest, APIResult* result);
		static int SendInvitation(SendInvitationManaged* managedRequest, APIResult* result);
		static int GetData(GetDataManaged* managedRequest, APIResult* result);
		static int SetMembersAsRecentlyMet(SetMembersAsRecentlyMetManaged* managedRequest, APIResult* result);  // SDK 4.5

		// Marshal methods
		static void MarshalGetWorlds(NptWorldsResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalRoom(NptRoomResponse* response, MemoryBuffer& buffer, APIResult* result);   // Used in both Create and Join room requests
		static void MarshalSearchRooms(NptSearchRoomsResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalRoomPingTime(NptRoomPingTimeResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalGetData(NptGetDataResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Notification
		static void MarshalRefreshRoom(NptRefreshRoomResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalInvitationReceived(NptInvitationReceivedResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalNewRoomMessage(NptNewRoomMessageResponse* response, MemoryBuffer& buffer,  APIResult* result);

		// System Events
		static void HandleSessionInvitationEvent(SceNpSessionInvitationEventParam* eventParam);

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		static void HandlePlayTogetherHostEvent(SceNpPlayTogetherHostEventParamA* eventParam);
#endif

		// Write methods
#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		static void WriteToBuffer(const SceNpPlayTogetherInvitee& world, MemoryBuffer& buffer);
#endif
		static void WriteToBuffer(const NpToolkit2::Matching::World& world, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Matching::Room& room, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Matching::Attribute& attribute, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Matching::AttributeMetadata& metadata, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpSessionId& sessionId, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpMatching2SessionPassword& password, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Matching::Member& member, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Matching::MemberSignalingInformation& signalingInformation, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpMatching2PresenceOptionData& optionData, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpInvitationId& invitationId, MemoryBuffer& buffer);

		// Room and member tracking

		class TrackedRoom
		{
		public:

			NptRoomResponse* response;
			UInt64 roomId;
		};

		static std::map<UInt64, TrackedRoom *> m_TrackedRooms;

		static void AddRoom(NptRoomResponse* nptResponse);
		static void RemoveRoom(UInt64 roomId);
		static void RefreshRoom(NptRefreshRoomResponse* response);
		static void RemovedLocalMemberFromRoom(SceNpMatching2RoomId roomId, SceUserServiceUserId userId);
		static TrackedRoom* GetTrackedRoom(UInt64 roomId);
		static NpToolkit2::Matching::Member* FindRoomMember(NptRoom* room, SceNpMatching2RoomMemberId roomMemberId);

	};
}





