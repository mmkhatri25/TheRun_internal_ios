#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	#define MAX_AGE_RESTRICTIONS (100)

	class Init
	{
	public:
		
		struct AgeRestriction
		{
			char* countryCode;
			Int32 age;
		};

		struct ContentRestriction
		{
			Int32 defaultAgeRestriction;
			AgeRestriction ageRestrictions[MAX_AGE_RESTRICTIONS];
			Int32 numAgeRestictions;
			bool applyContentRestriction;
		};

		struct ServerPushNotifications // Depricated
		{
			bool newGameDataMessage;
			bool newInvitation;
			bool updateBlockedUsersList;
			bool updateFriendPresence;
			bool updateFriendsList;
			bool newInGameMessage;
		};

        enum ServerPushNotificationsFlags
        {
            newGameDataMessage = (1<<0),
            newInvitation = (1<<1),
            updateBlockedUsersList = (1<<2),
            updateFriendPresence = (1<<3),
            updateFriendsList = (1<<4),
            newInGameMessage = (1<<5),
        };

		struct ThreadSettings
		{
			UInt32 affinityFlags;
		};

		struct MemoryPools
		{
			UInt64 npToolkitPoolSize;			///< The size of the internal memory pool used by the ToolkitNp2 library.
			UInt64 jsonPoolSize;				///< The size of the JSON memory pool.
			UInt64 webApiPoolSize;				///< The size of the WebAPI memory pool.
			UInt64 httpPoolSize;				///< The size of the HTTP memory pool.
			UInt64 sslPoolSize;					///< The size of the SSL memory pool.
			UInt64 netPoolSize;					///< The size of the Net memory pool.
			UInt64 matchingPoolSize;			///< The size of the memory pool of the NpMatching2 library. This is ignored if the Matching service is not used.
			UInt64 matchingSslPoolSize;			///< The size of the SSL memory pool of the NpMatching2 library. This is ignored if the Matching service is not used.
			UInt64 inGameMessagePoolSize;		///< The size of the memory pool of the NpInGameMessage library. This is ignored if In-Game messages are not used.					
		};

		class InitToolkit
		{
		public:
			ContentRestriction contentRestrictions;
			ServerPushNotifications serverPushNotifications; // Deprecate
            UInt32 pushNotificationFlags;
            bool pushNotificationFlagsSet;
			ThreadSettings threadSettings;
			MemoryPools memPools;
		};

		struct InitResult
		{
		public:
			bool initialized;
			UInt32 sceSDKVersion; // SCE_ORBIS_SDK_VERSION 

			InitResult()
			{
				initialized = false;
			}
		};

		static void InitializeToolkitInternal(InitToolkit& init, Init::InitResult& initResult, NpToolkit2::Core::NpToolkitCallback npToolkitCallback, APIResult* result);

		static SceUserServiceUserId GetPrimaryUserId()
		{
			return s_PrimaryUserId;
		}

	private:
		static SceNpAgeRestriction s_ageRestriction[MAX_AGE_RESTRICTIONS];
		static bool InitializeAgeRatingsInternal(ContentRestriction& restriction, APIResult* result);
		static SceUserServiceUserId s_PrimaryUserId;
	};
}





