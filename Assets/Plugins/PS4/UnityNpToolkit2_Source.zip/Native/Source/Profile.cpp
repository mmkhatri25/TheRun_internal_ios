#include <stdio.h>

#include "Profile.h"

namespace NPT
{
	void Profile::WriteToBuffer(const NpToolkit2::UserProfile::RealName& npRealName, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::RealNameBegin);

		buffer.WriteString(npRealName.firstName);
		buffer.WriteString(npRealName.middleName);
		buffer.WriteString(npRealName.lastName);

		buffer.WriteMarker(BufferIntegrityChecks::RealNameEnd);
	}

	void Profile::WriteToBuffer(const NpToolkit2::UserProfile::NpProfile& npProfile, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ProfileBegin);

		Core::WriteToBuffer(npProfile.onlineUser, buffer);

		buffer.WriteUInt32((UInt32)npProfile.relation);

		// Write array size
		buffer.WriteUInt32((UInt32)NpToolkit2::UserProfile::NpProfile::MAX_NUM_LANGUAGES_USED);
		for(int i =0; i < NpToolkit2::UserProfile::NpProfile::MAX_NUM_LANGUAGES_USED; i++)
		{
			Core::WriteToBuffer(npProfile.languagesUsed[i], buffer);
		}

		Core::WriteToBuffer(npProfile.country, buffer);

		buffer.WriteUInt32((UInt32)npProfile.personalDetailsAvailable);

		if ( npProfile.personalDetailsAvailable == NpToolkit2::UserProfile::PersonalDetailsType::realName )  ///< The user has set the real name
		{
			WriteToBuffer(npProfile.personalDetails.realName, buffer);
		}
		else if ( npProfile.personalDetailsAvailable == NpToolkit2::UserProfile::PersonalDetailsType::verifiedAccountDisplayName ) ///< The user has a verified account with a display name set
		{
			buffer.WriteString(npProfile.personalDetails.verifiedAccountDisplayName);
		}

		buffer.WriteString(npProfile.aboutMe);
		buffer.WriteString(npProfile.avatarUrl);
		buffer.WriteString(npProfile.profilePictureUrl);

		buffer.WriteBool(npProfile.isVerifiedAccount);

		buffer.WriteMarker(BufferIntegrityChecks::ProfileEnd);
	}

}
