
#include "MarshalResponse.h"

#include "Core.h"
#include "Friends.h"
#include "Presence.h"
#include "UserProfiles.h"
#include "NpUtils.h"
#include "NetworkUtils.h"
#include "Trophies.h"
#include "Ranking.h"
#include "Matching.h"
#include "Tss.h"
#include "Tus.h"
#include "Messaging.h"
#include "Commerce.h"
#include "Auth.h"
#include "WordFilter.h"
#include "ActivityFeed.h"

namespace NPT
{

	// Get the first part of the Friends response. Currently this just contains the number of friends 
	DO_EXPORT( void, PrxMarshalResponse ) (UInt32 npRequestId, Int32 apiCalled, MemoryBufferManaged* outBuffer, APIResult* result)
	{
		MarshalResponse::Read(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled, outBuffer, result);
	}

	void MarshalResponse::Read(UInt32 npRequestId, NpToolkit2::Core::FunctionType apiCalled, MemoryBufferManaged* outBuffer, APIResult* result)
	{
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(npRequestId, apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, apiCalled);

		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return;
		}

		MemoryBuffer* buffer = ResponseMap::GetMemoryResultsBuffer(npRequestId, apiCalled);

		if ( buffer == NULL)
		{
			ERROR_RESULT(result,"The output buffer in ResponseMap is empty.");
			return;
		}

		buffer->CopyTo(outBuffer);

		SUCCESS_RESULT(result);
	}

	// Called from the NpToolkit thread to copy the response data into a block of memory.
	// This needs to be done as Notification response instances are freed by NpToolkit after the callback has finished and can't be kept. 
	MemoryBuffer& MarshalResponse::WriteToBuffer(NpToolkit2::Core::ResponseBase* response, NpToolkit2::Core::FunctionType apiCalled, APIResult* result)
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();		
		buffer.StartResponseWrite();

		//
		//
		// Add Function types to call the correct read method depending on the type of response object the apiCalled uses.
		//
		//
		switch(apiCalled)
		{
		case NpToolkit2::Core::FunctionType::friendsGetFriends:
			Friends::MarshalFriends((Friends::NptFriendsResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::friendsGetFriendsOfFriends:
			Friends::MarshalFriendsOfFriends((Friends::NptFriendsOfFriendsResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::friendsGetBlockedUsers:
			Friends::MarshalBlockedUsers((Friends::NptBlockedUsersResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::notificationUpdateFriendsList:
			Friends::MarshalFriendlistUpdate((Friends::NptFriendlistUpdateResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::notificationUpdateBlockedUsersList:
			Friends::MarshalBlocklistUpdate((Friends::NptBlocklistUpdateResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::notificationUpdateFriendPresence:
			Presence::MarshalPresenceUpdate((Presence::NptPresenceUpdateResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::userProfileGetNpProfiles:
		case NpToolkit2::Core::FunctionType::userProfileGetVerifiedAccountsForTitle:
			UserProfiles::MarshalNpProfiles((UserProfiles::NptProfilesResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::notificationUserStateChange:
			NpUtils::MarshalUserStateChange((NpUtils::NptUserStateChangeResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::networkUtilsGetBandwidthInfo:
			NetworkUtils::MarshalBandwidthInfo((NetworkUtils::NptBandwidthInfoResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::networkUtilsGetBasicNetworkInfo:
			NetworkUtils::MarshalNetStateBasic((NetworkUtils::NptNetStateBasicResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::networkUtilsGetDetailedNetworkInfo:
			NetworkUtils::MarshalNetStateDetailed((NetworkUtils::NptNetStateDetailedResponse*)response, buffer, result);
			break;
		case NpToolkit2::Core::FunctionType::notificationNetStateChange:
			NetworkUtils::MarshalNetStateChange((NetworkUtils::NptNetStateChangeResponse*)response, buffer, result);			
			break;

		case NpToolkit2::Core::FunctionType::trophyGetUnlockedTrophies:
			Trophies::MarshalUnlockedTrophies((Trophies::NptUnlockedTrophiesResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackSummary:
			Trophies::MarshalTrophyPackSummary((Trophies::NptTrophyPackSummaryResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackGroup:
			Trophies::MarshalTrophyPackGroup((Trophies::NptTrophyPackGroupResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackTrophy:
			Trophies::MarshalTrophyPackTrophy((Trophies::NptTrophyPackTrophyResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::presenceGetPresence:
			Presence::MarshalPresence((Presence::NptPresenceResponse*)response, buffer, result);
			break;		

		case NpToolkit2::Core::FunctionType::rankingSetScore:
			Ranking::MarshalTempRank((Ranking::NptTempRankResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetRangeOfRanks:
			Ranking::MarshalRangeOfRanks((Ranking::NptRangeOfRanksResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetFriendsRanks:
			Ranking::MarshalFriendsRanks((Ranking::NptFriendsRanksResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetUsersRanks:
			Ranking::MarshalUsersRanks((Ranking::NptUsersRanksResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::rankingSetGameData:
			Ranking::MarshalSetGameDataResult((Ranking::NptSetGameDataResultResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetGameData:
			Ranking::MarshalGetGameDataResult((Ranking::NptGetGameDataResultResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetWorlds:
			Matching::MarshalGetWorlds((Matching::NptWorldsResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::matchingCreateRoom:
			Matching::MarshalRoom((Matching::NptRoomResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::matchingSearchRooms:
			Matching::MarshalSearchRooms((Matching::NptSearchRoomsResponse*)response, buffer, result);
			break;			

		case NpToolkit2::Core::FunctionType::matchingJoinRoom:
			Matching::MarshalRoom((Matching::NptRoomResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetRoomPingTime:
			Matching::MarshalRoomPingTime((Matching::NptRoomPingTimeResponse*)response, buffer, result);
			break;		

		case NpToolkit2::Core::FunctionType::matchingGetData:
			Matching::MarshalGetData((Matching::NptGetDataResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetAttributes:
		case NpToolkit2::Core::FunctionType::notificationRefreshRoom:
			Matching::MarshalRefreshRoom((Matching::NptRefreshRoomResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::notificationNewInvitation:
			Matching::MarshalInvitationReceived((Matching::NptInvitationReceivedResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::notificationNewRoomMessage:
			Matching::MarshalNewRoomMessage((Matching::NptNewRoomMessageResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::tssGetData:
			TSS::MarshalTssData((TSS::NptTssDataResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::tusGetVariables:
			TUS::MarshalTusVariables((TUS::NptTusVariablesResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::tusAddToAndGetVariable:
			#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			TUS::MarshalTusVariables((TUS::NptTusVariablesResponse*)response, buffer, result);
			#else
			TUS::MarshalAtomicAddToAndGetVariable((TUS::NptAtomicAddToAndGetVariableResponse*)response, buffer, result);
			#endif
			break;	

		case NpToolkit2::Core::FunctionType::tusGetData:
			TUS::MarshalTusData((TUS::NptTusDataResponse*)response, buffer, result);
			break;	

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		case NpToolkit2::Core::FunctionType::tusTryAndSetVariable:
			TUS::MarshalTusVariables((TUS::NptTusVariablesResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::tusGetFriendsVariable:
			TUS::MarshalTusFriendsVariable((TUS::NptTusFriendsVariablesResponse*)response, buffer, result);
			break;	
		case NpToolkit2::Core::FunctionType::tusGetUsersVariable:
			TUS::MarshalTusVariables((TUS::NptTusVariablesResponse*)response, buffer, result);
			break;	
		case NpToolkit2::Core::FunctionType::tusGetUsersDataStatus:
			TUS::MarshalTusDataStatuses((TUS::NptTusDataStatusesResponse*)response, buffer, result);
			break;	
		case NpToolkit2::Core::FunctionType::tusGetFriendsDataStatus:
			TUS::MarshalTusFriendsDataStatusesResponse((TUS::NptTusFriendsDataStatusesResponse*)response, buffer, result);
			break;	
#endif

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::messagingGetReceivedGameDataMessages:
			Messaging::MarshalGameDataMessages((Messaging::NptGameDataMessagesResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::messagingGetGameDataMessageThumbnail:
			Messaging::MarshalGameDataMessageThumbnail((Messaging::NptGameDataMessageThumbnailResponse*)response, buffer, result);
			break;	

		case NpToolkit2::Core::FunctionType::messagingGetGameDataMessageAttachment:
			Messaging::MarshalGameDataMessageAttachment((Messaging::NptGameDataMessageAttachmentResponse*)response, buffer, result);
			break;	
#endif

		case NpToolkit2::Core::FunctionType::notificationNewInGameMessage:
			Messaging::MarshalNewInGameMessage((Messaging::NptNewInGameMessageResponse*)response, buffer, result);
			break;	

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::notificationNewGameDataMessage:
			Messaging::MarshalNewGameDataMessage((Messaging::NptNewGameDataMessageResponse*)response, buffer, result);
			break;
#endif

		case NpToolkit2::Core::FunctionType::commerceGetCategories:
			Commerce::MarshalCategories((Commerce::NptCategoriesResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::commerceGetProducts:
			Commerce::MarshalProducts((Commerce::NptProductsResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::commerceGetServiceEntitlements:
			Commerce::MarshalServiceEntitlements((Commerce::NptServiceEntitlementsResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::authGetAuthCode:
			Auth::MarshalAuthCode((Auth::NptAuthCodeResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::authGetIdToken:
			Auth::MarshalIdToken((Auth::NptIdTokenResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::wordfilterFilterComment:
			WordFilter::MarshalSanitizedComment((WordFilter::NptSanitizedCommentResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetFeed:
			ActivityFeed::MarshalFeed((ActivityFeed::NptFeedResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetWhoLiked:
			ActivityFeed::MarshalUsersWhoLiked((ActivityFeed::NptUsersWhoLikedResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetPlayedWith:
			ActivityFeed::MarshalPlayedWithFeed((ActivityFeed::NptPlayedWithFeedResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetSharedVideos:
			ActivityFeed::MarshalSharedVideos((ActivityFeed::NptSharedVideosResponse*)response, buffer, result);
			break;

		case NpToolkit2::Core::FunctionType::friendsDisplayFriendRequestDialog:
		case NpToolkit2::Core::FunctionType::friendsDisplayBlockUserDialog:
		case NpToolkit2::Core::FunctionType::userProfileDisplayUserProfileDialog:
		case NpToolkit2::Core::FunctionType::userProfileDisplayGriefReportingDialog:
		case NpToolkit2::Core::FunctionType::notificationDialogOpened:
		case NpToolkit2::Core::FunctionType::notificationDialogClosed:
		case NpToolkit2::Core::FunctionType::notificationAborted:
		case NpToolkit2::Core::FunctionType::trophyDisplayTrophyListDialog:
		case NpToolkit2::Core::FunctionType::trophyRegisterTrophyPack:
		case NpToolkit2::Core::FunctionType::trophyUnlock:
		case NpToolkit2::Core::FunctionType::trophySetScreenshot:
		case NpToolkit2::Core::FunctionType::npUtilsSetTitleIdForDevelopment:
		case NpToolkit2::Core::FunctionType::npUtilsDisplaySigninDialog:
		case NpToolkit2::Core::FunctionType::npUtilsCheckAvailability:
		case NpToolkit2::Core::FunctionType::presenceDeletePresence:
		case NpToolkit2::Core::FunctionType::presenceSetPresence:
		case NpToolkit2::Core::FunctionType::matchingSetInitConfiguration:
		case NpToolkit2::Core::FunctionType::matchingSendInvitation:
		case NpToolkit2::Core::FunctionType::matchingSetRoomInfo:
		case NpToolkit2::Core::FunctionType::matchingLeaveRoom:
		case NpToolkit2::Core::FunctionType::matchingKickOutRoomMember:
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		case NpToolkit2::Core::FunctionType::matchingSetMembersAsRecentlyMet:
#endif
		case NpToolkit2::Core::FunctionType::tusSetVariables:
		case NpToolkit2::Core::FunctionType::tusSetData:
		case NpToolkit2::Core::FunctionType::tusDeleteData:
		case NpToolkit2::Core::FunctionType::messagingSendInGameMessage:
#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::messagingSendGameDataMessage:
		case NpToolkit2::Core::FunctionType::messagingDisplayReceivedGameDataMessagesDialog:
		case NpToolkit2::Core::FunctionType::messagingConsumeGameDataMessage:
#endif
		case NpToolkit2::Core::FunctionType::commerceConsumeServiceEntitlement:
		case NpToolkit2::Core::FunctionType::commerceDisplayCategoryBrowseDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayProductBrowseDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayVoucherCodeInputDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayCheckoutDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayJoinPlusDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayDownloadListDialog:
		case NpToolkit2::Core::FunctionType::commerceSetPsStoreIconDisplayState:	
		case NpToolkit2::Core::FunctionType::coreTerminateService:
		case NpToolkit2::Core::FunctionType::activityFeedPostInGameStory:
		case NpToolkit2::Core::FunctionType::activityFeedSetLiked:
		case NpToolkit2::Core::FunctionType::activityFeedPostPlayedWith:

			Core::MarshalEmpty((Core::NptEmptyResponse*)response, buffer, result);
			break;
	
		default:
			ERROR_RESULT(result,"MarshalResponse::Read : API response not supported");
			break;
		}
		//
		//
		//
		//

		buffer.FinishResponseWrite();

		return buffer;
	}

	// Delete each response object based on type. This has to be done because the destructor in ResponseBase is private.
	void MarshalResponse::DeleteResponse(NpToolkit2::Core::ResponseBase* response, NpToolkit2::Core::FunctionType apiCalled)
	{
		switch(apiCalled)
		{
		case NpToolkit2::Core::FunctionType::friendsGetFriends:
			delete (Friends::NptFriendsResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::friendsGetFriendsOfFriends:
			delete (Friends::NptFriendsOfFriendsResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::friendsGetBlockedUsers:
			delete (Friends::NptBlockedUsersResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::notificationUpdateFriendsList:
			delete (Friends::NptFriendlistUpdateResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::notificationUpdateBlockedUsersList:
			delete (Friends::NptBlocklistUpdateResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::notificationUpdateFriendPresence:
			delete (Presence::NptPresenceUpdateResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::userProfileGetNpProfiles:
		case NpToolkit2::Core::FunctionType::userProfileGetVerifiedAccountsForTitle:
			delete (UserProfiles::NptProfilesResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::notificationUserStateChange:
			delete (NpUtils::NptUserStateChangeResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::networkUtilsGetBandwidthInfo:
			delete (NetworkUtils::NptBandwidthInfoResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::networkUtilsGetBasicNetworkInfo:
			delete (NetworkUtils::NptNetStateBasicResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::networkUtilsGetDetailedNetworkInfo:
			delete (NetworkUtils::NptNetStateDetailedResponse*)response;
			break;
		case NpToolkit2::Core::FunctionType::notificationNetStateChange:
			delete (NetworkUtils::NptNetStateChangeResponse*)response;			
			break;

		case NpToolkit2::Core::FunctionType::trophyGetUnlockedTrophies:
			delete (Trophies::NptUnlockedTrophiesResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackSummary:
			delete (Trophies::NptTrophyPackSummaryResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackGroup:
			delete (Trophies::NptTrophyPackGroupResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::trophyGetTrophyPackTrophy:
			delete (Trophies::NptTrophyPackTrophyResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::presenceGetPresence:
			delete (Presence::NptPresenceResponse*)response;
			break;		

		case NpToolkit2::Core::FunctionType::rankingSetScore:
			delete (Ranking::NptTempRankResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetRangeOfRanks:
			delete (Ranking::NptRangeOfRanksResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetFriendsRanks:
			delete (Ranking::NptFriendsRanksResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetUsersRanks:
			delete (Ranking::NptUsersRanksResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::rankingSetGameData:
			delete (Ranking::NptSetGameDataResultResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::rankingGetGameData:
			delete (Ranking::NptGetGameDataResultResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetWorlds:
			delete (Matching::NptWorldsResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::matchingCreateRoom:
		//	delete (Matching::NptRoomResponse*)response; // This is deleted under special conditions when the room is destroyed.
			break;	

		case NpToolkit2::Core::FunctionType::matchingSearchRooms:
			delete (Matching::NptSearchRoomsResponse*)response;
			break;			

		case NpToolkit2::Core::FunctionType::matchingJoinRoom:
		//	delete (Matching::NptRoomResponse*)response; // This is deleted under special conditions when the room is destroyed.
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetRoomPingTime:
			delete (Matching::NptRoomPingTimeResponse*)response;
			break;		

		case NpToolkit2::Core::FunctionType::matchingGetData:
			delete (Matching::NptGetDataResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::matchingGetAttributes:
		case NpToolkit2::Core::FunctionType::notificationRefreshRoom:
			delete (Matching::NptRefreshRoomResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::notificationNewInvitation:
			delete (Matching::NptInvitationReceivedResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::notificationNewRoomMessage:
			delete (Matching::NptNewRoomMessageResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::tssGetData:
			delete (TSS::NptTssDataResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::tusGetVariables:
			delete (TUS::NptTusVariablesResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::tusAddToAndGetVariable:
#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			delete (TUS::NptTusVariablesResponse*)response;
#else
			delete (TUS::NptAtomicAddToAndGetVariableResponse*)response;
#endif
			break;	

		case NpToolkit2::Core::FunctionType::tusGetData:
			delete (TUS::NptTusDataResponse*)response;
			break;	

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		case NpToolkit2::Core::FunctionType::tusTryAndSetVariable:
			delete (TUS::NptTusVariablesResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::tusGetFriendsVariable:
			delete (TUS::NptTusFriendsVariablesResponse*)response;
			break;	
		case NpToolkit2::Core::FunctionType::tusGetUsersVariable:
			delete (TUS::NptTusVariablesResponse*)response;
			break;	
		case NpToolkit2::Core::FunctionType::tusGetUsersDataStatus:
			delete (TUS::NptTusDataStatusesResponse*)response;
			break;	
		case NpToolkit2::Core::FunctionType::tusGetFriendsDataStatus:
			delete (TUS::NptTusFriendsDataStatusesResponse*)response;
			break;	
#endif

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::messagingGetReceivedGameDataMessages:
			delete (Messaging::NptGameDataMessagesResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::messagingGetGameDataMessageThumbnail:
			delete (Messaging::NptGameDataMessageThumbnailResponse*)response;
			break;	

		case NpToolkit2::Core::FunctionType::messagingGetGameDataMessageAttachment:
			delete (Messaging::NptGameDataMessageAttachmentResponse*)response;
			break;
#endif

		case NpToolkit2::Core::FunctionType::notificationNewInGameMessage:
			delete (Messaging::NptNewInGameMessageResponse*)response;
			break;	

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::notificationNewGameDataMessage:
			delete (Messaging::NptNewGameDataMessageResponse*)response;
			break;
#endif

		case NpToolkit2::Core::FunctionType::commerceGetCategories:
			delete (Commerce::NptCategoriesResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::commerceGetProducts:
			delete (Commerce::NptProductsResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::commerceGetServiceEntitlements:
			delete (Commerce::NptServiceEntitlementsResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::authGetAuthCode:
			delete (Auth::NptAuthCodeResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::authGetIdToken:
			delete (Auth::NptIdTokenResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::wordfilterFilterComment:
			delete (WordFilter::NptSanitizedCommentResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetFeed:
			delete (ActivityFeed::NptFeedResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetWhoLiked:
			delete (ActivityFeed::NptUsersWhoLikedResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetPlayedWith:
			delete (ActivityFeed::NptPlayedWithFeedResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::activityFeedGetSharedVideos:
			delete (ActivityFeed::NptSharedVideosResponse*)response;
			break;

		case NpToolkit2::Core::FunctionType::friendsDisplayFriendRequestDialog:
		case NpToolkit2::Core::FunctionType::friendsDisplayBlockUserDialog:
		case NpToolkit2::Core::FunctionType::userProfileDisplayUserProfileDialog:
		case NpToolkit2::Core::FunctionType::userProfileDisplayGriefReportingDialog:
		case NpToolkit2::Core::FunctionType::notificationDialogOpened:
		case NpToolkit2::Core::FunctionType::notificationDialogClosed:
		case NpToolkit2::Core::FunctionType::notificationAborted:
		case NpToolkit2::Core::FunctionType::trophyDisplayTrophyListDialog:
		case NpToolkit2::Core::FunctionType::trophyRegisterTrophyPack:
		case NpToolkit2::Core::FunctionType::trophyUnlock:
		case NpToolkit2::Core::FunctionType::trophySetScreenshot:
		case NpToolkit2::Core::FunctionType::npUtilsSetTitleIdForDevelopment:
		case NpToolkit2::Core::FunctionType::npUtilsDisplaySigninDialog:
		case NpToolkit2::Core::FunctionType::npUtilsCheckAvailability:
		case NpToolkit2::Core::FunctionType::presenceDeletePresence:
		case NpToolkit2::Core::FunctionType::presenceSetPresence:
		case NpToolkit2::Core::FunctionType::matchingSetInitConfiguration:
		case NpToolkit2::Core::FunctionType::matchingLeaveRoom:
		case NpToolkit2::Core::FunctionType::matchingKickOutRoomMember:
		case NpToolkit2::Core::FunctionType::matchingSendInvitation:
		case NpToolkit2::Core::FunctionType::matchingSetRoomInfo:
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		case NpToolkit2::Core::FunctionType::matchingSetMembersAsRecentlyMet:
#endif
		case NpToolkit2::Core::FunctionType::tusSetVariables:
		case NpToolkit2::Core::FunctionType::tusSetData:
		case NpToolkit2::Core::FunctionType::tusDeleteData:
		case NpToolkit2::Core::FunctionType::messagingSendInGameMessage:
#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		case NpToolkit2::Core::FunctionType::messagingSendGameDataMessage:
		case NpToolkit2::Core::FunctionType::messagingDisplayReceivedGameDataMessagesDialog:
		case NpToolkit2::Core::FunctionType::messagingConsumeGameDataMessage:
#endif
		case NpToolkit2::Core::FunctionType::commerceConsumeServiceEntitlement:
		case NpToolkit2::Core::FunctionType::commerceDisplayCategoryBrowseDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayProductBrowseDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayVoucherCodeInputDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayCheckoutDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayJoinPlusDialog:
		case NpToolkit2::Core::FunctionType::commerceDisplayDownloadListDialog:
		case NpToolkit2::Core::FunctionType::commerceSetPsStoreIconDisplayState:	
		case NpToolkit2::Core::FunctionType::coreTerminateService:
		case NpToolkit2::Core::FunctionType::activityFeedPostInGameStory:
		case NpToolkit2::Core::FunctionType::activityFeedSetLiked:
		case NpToolkit2::Core::FunctionType::activityFeedPostPlayedWith:
			delete (Core::NptEmptyResponse*)response;
			break;



		default:
			break;
		}

	}
}
