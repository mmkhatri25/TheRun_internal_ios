
#include "Commerce.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxGetCategories ) (GetCategoriesManaged* managedRequest, APIResult* result)
	{
		return Commerce::GetCategories(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetProducts ) (GetProductsManaged* managedRequest, APIResult* result)
	{
		return Commerce::GetProducts(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetServiceEntitlements ) (GetServiceEntitlementsManaged* managedRequest, APIResult* result)
	{
		return Commerce::GetServiceEntitlements(managedRequest, result);
	}

	DO_EXPORT( int, PrxConsumeServiceEntitlement ) (ConsumeServiceEntitlementManaged* managedRequest, APIResult* result)
	{
		return Commerce::ConsumeServiceEntitlement(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayCategoryBrowseDialog ) (DisplayCategoryBrowseDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayCategoryBrowseDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayProductBrowseDialog ) (DisplayProductBrowseDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayProductBrowseDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayVoucherCodeInputDialog ) (DisplayVoucherCodeInputDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayVoucherCodeInputDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayCheckoutDialog ) (DisplayCheckoutDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayCheckoutDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayDownloadListDialog ) (DisplayDownloadListDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayDownloadListDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayJoinPlusDialog ) (DisplayJoinPlusDialogManaged* managedRequest, APIResult* result)
	{
		return Commerce::DisplayJoinPlusDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetPsStoreIconDisplayState ) (SetPsStoreIconDisplayStateManaged* managedRequest, APIResult* result)
	{
		return Commerce::SetPsStoreIconDisplayState(managedRequest, result);
	}

	void CategoryLabelManaged::CopyTo(CategoryLabel &destination)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		strcpy_s(destination.value, CATEGORY_LABEL_MAX_LEN + 1, value);
#else
		strcpy_s(destination.id, CATEGORY_LABEL_MAX_LEN + 1, value);
#endif
	}

	void ProductLabelManaged::CopyTo(ProductLabel &destination)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		strcpy_s(destination.value, PRODUCT_LABEL_MAX_LEN + 1, value);
#else
		strcpy_s(destination.id, PRODUCT_LABEL_MAX_LEN + 1, value);
#endif
	}

	void SkuLabelManaged::CopyTo(SkuLabel &destination)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		strcpy_s(destination.value, SKU_LABEL_MAX_LEN + 1, value);
#else
		strcpy_s(destination.id, SKU_LABEL_MAX_LEN + 1, value);
#endif
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	void ServiceEntitlementLabelManaged::CopyTo(sce::Toolkit::NP::Commerce::ServiceEntitlementLabel &destination)
	{
		strcpy_s(destination.value, SERVICE_ENTITLEMENT_LABEL_MAX_LEN + 1, value);
	}
#endif

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	void CheckoutTargetManaged::CopyTo(NpToolkit2::Commerce::Request::CheckoutTarget &destination)
	{
		productLabel.CopyTo(destination.productLabel);
		skuLabel.CopyTo(destination.skuLabel);

		destination.serviceLabel = serviceLabel;
	}
#endif

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	void DownloadListTargetManaged::CopyTo(NpToolkit2::Commerce::Request::DownloadListTarget &destination)
	{
		productLabel.CopyTo(destination.productLabel);
		skuLabel.CopyTo(destination.skuLabel);
	}
#endif

	void GetCategoriesManaged::CopyTo(NpToolkit2::Commerce::Request::GetCategories &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.numCategories = numCategories;

		for(int i =0; i < numCategories; i++)
		{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
			categoryLabels[i].CopyTo(destination.categoryLabels[i]);
#else
			categoryLabels[i].CopyTo(destination.categoryIds[i]);
#endif
		}
	}

	void GetProductsManaged::CopyTo(NpToolkit2::Commerce::Request::GetProducts &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		destination.numProducts = numProducts;
#else
		destination.numProductIds = numProducts;
#endif

		for(int i =0; i < numProducts; i++)
		{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
			productLabels[i].CopyTo(destination.productLabels[i]);
#else
			productLabels[i].CopyTo(destination.productIds[i]);
#endif
		}

		destination.numCategories = numCategories;

		for(int i =0; i < numCategories; i++)
		{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
			categoryLabels[i].CopyTo(destination.categoryLabels[i]);
#else
			categoryLabels[i].CopyTo(destination.categoryIds[i]);
#endif
		}

		destination.offset = offset;
		destination.pageSize = pageSize;
		destination.sortOrder = sortOrder;
		destination.sortDirection = sortDirection;
		destination.keepHtmlTags = keepHtmlTags;
		destination.useCurrencySymbol = useCurrencySymbol;
	}

	void GetServiceEntitlementsManaged::CopyTo(NpToolkit2::Commerce::Request::GetServiceEntitlements &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.offset = offset;
		destination.pageSize = pageSize;
	}

	void ConsumeServiceEntitlementManaged::CopyTo(NpToolkit2::Commerce::Request::ConsumeServiceEntitlement &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		entitlementLabel.CopyTo(destination.entitlementLabel);
#else
		strcpy_s(destination.entitlementId, NpToolkit2::Commerce::Request::ConsumeServiceEntitlement::ENTITLEMENT_ID_LEN+1, entitlementLabel.value);
#endif
		destination.consumedCount = consumedCount;
	}

	void DisplayCategoryBrowseDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayCategoryBrowseDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		categoryLabel.CopyTo(destination.categoryLabel);
#else
		strcpy_s(destination.categoryId, NpToolkit2::Commerce::Request::DisplayCategoryBrowseDialog::CATEGORY_ID_LEN+1, categoryLabel.value);
#endif
	}

	void DisplayProductBrowseDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayProductBrowseDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		productLabel.CopyTo(destination.productLabel);
#else
		strcpy_s(destination.productId, NpToolkit2::Commerce::Request::DisplayProductBrowseDialog::PRODUCT_ID_LEN+1, productLabel.value);
#endif
	}

	void DisplayVoucherCodeInputDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayVoucherCodeInputDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		strcpy_s(destination.voucherCode, NpToolkit2::Commerce::Request::DisplayVoucherCodeInputDialog::VOUCHER_CODE_LEN+1, voucherCode);
	}

	void DisplayCheckoutDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayCheckoutDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		destination.numTargets = numTargets;

		for(int i = 0; i < numTargets; i++)
		{
			targets[i].CopyTo(destination.targets[i]);
		}
#else
		destination.numSkuIds = numTargets;

		for(int i = 0; i < numTargets; i++)
		{
			targets[i].skuLabel.CopyTo(destination.skuIds[i]);
		}
#endif
	}

	bool DisplayCheckoutDialogManaged::Validate(APIResult* result)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		for(int i = 0; i < numTargets; i++)
		{
			if ( strlen(targets[i].skuLabel.value) == 0 )
			{
				// A SkuLabel is not defined. Therefore serviceLabel shouldn't be set either
				if ( targets[i].serviceLabel != SCE_NP_INVALID_SERVICE_LABEL)
				{
					// Error
					ERROR_RESULT(result, "A ServiceLabel has been set but the SkuLabel is empty");
					return false;
				}
			}
			else
			{
				// A SkuLabel is defined. Therefore serviceLabel must also be set
				if ( targets[i].serviceLabel == SCE_NP_INVALID_SERVICE_LABEL)
				{
					// Error
					ERROR_RESULT(result, "A ServiceLabel has not been set but the SkuLabel has been.");
					return false;
				}
			}
		}
#endif

		return true;
	}

	void DisplayDownloadListDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayDownloadListDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		destination.numTargets = numTargets;

		for(int i = 0; i < numTargets; i++)
		{
			targets[i].CopyTo(destination.targets[i]);
		}
#else
		destination.numSkuIds = numTargets;

		for(int i = 0; i < numTargets; i++)
		{
			targets[i].skuLabel.CopyTo(destination.skuIds[i]);
		}
#endif
	}

	void DisplayJoinPlusDialogManaged::CopyTo(NpToolkit2::Commerce::Request::DisplayJoinPlusDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.features = features;
	}

	void SetPsStoreIconDisplayStateManaged::CopyTo(NpToolkit2::Commerce::Request::SetPsStoreIconDisplayState &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.iconPosition = iconPosition;
		destination.showIcon = showIcon;	
	}

	//Requests
	int Commerce::GetCategories(GetCategoriesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptCategoriesResponse * nptResponse = new NptCategoriesResponse();

		NpToolkit2::Commerce::Request::GetCategories nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::getCategories(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::GetProducts(GetProductsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptProductsResponse * nptResponse = new NptProductsResponse();

		NpToolkit2::Commerce::Request::GetProducts nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::getProducts(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::GetServiceEntitlements(GetServiceEntitlementsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptServiceEntitlementsResponse * nptResponse = new NptServiceEntitlementsResponse();

		NpToolkit2::Commerce::Request::GetServiceEntitlements nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::getServiceEntitlements(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::ConsumeServiceEntitlement(ConsumeServiceEntitlementManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::ConsumeServiceEntitlement nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::consumeServiceEntitlement(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayCategoryBrowseDialog(DisplayCategoryBrowseDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayCategoryBrowseDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayCategoryBrowseDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayProductBrowseDialog(DisplayProductBrowseDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayProductBrowseDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayProductBrowseDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayVoucherCodeInputDialog(DisplayVoucherCodeInputDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayVoucherCodeInputDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayVoucherCodeInputDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayCheckoutDialog(DisplayCheckoutDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		if ( managedRequest->Validate(result) == false )
		{
			return -1;
		}

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayCheckoutDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayCheckoutDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayDownloadListDialog(DisplayDownloadListDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayDownloadListDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayDownloadListDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::DisplayJoinPlusDialog(DisplayJoinPlusDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::DisplayJoinPlusDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::displayJoinPlusDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Commerce::SetPsStoreIconDisplayState(SetPsStoreIconDisplayStateManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Commerce::Request::SetPsStoreIconDisplayState nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Commerce::setPsStoreIconDisplayState(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}


	// Marshal responses
	void Commerce::MarshalCategories(NptCategoriesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::CategoriesBegin);

		const NptCategories* categories = response->get();

		buffer.WriteUInt64(categories->numCategories);
		
		for(int i = 0; i < categories->numCategories; i++)
		{
			WriteToBuffer(categories->categories[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::CategoriesEnd);

		SUCCESS_RESULT(result);
	}

	void Commerce::MarshalProducts(NptProductsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ProductsBegin);

		const NptProducts* products = response->get();

		buffer.WriteUInt64(products->numProducts);
		
		for(int i = 0; i < products->numProducts; i++)
		{
			// Private support ticket 111065 - Some products, which have details, are incorrectly flagged with hasDetails being false.
			// If the first product has "hasDetail" true then all the rest of the product can be considered true. 
			// If first Product has is false then false for the rest. 
			WriteToBuffer(products->products[i], products->products[0].hasDetails, buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::ProductsEnd);

		SUCCESS_RESULT(result);
	}

	void Commerce::MarshalServiceEntitlements(NptServiceEntitlementsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ServiceEntitlementsBegin);

		const NptServiceEntitlements* serviceEntitlements = response->get();

		buffer.WriteUInt64(serviceEntitlements->totalEntitlementsAvailable);
		buffer.WriteUInt64(serviceEntitlements->numEntitlements);

		for(int i = 0; i < serviceEntitlements->numEntitlements; i++)
		{
			WriteToBuffer(serviceEntitlements->entitlements[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::ServiceEntitlementsEnd);

		SUCCESS_RESULT(result);
	}

	// Write Methods
	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::Category& category, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::CategoryBegin);

		buffer.WriteUInt64(category.numSubCategories);
		
		for(int i = 0; i < category.numSubCategories; i++)
		{
			WriteToBuffer(category.subCategories[i], buffer);
		}

		buffer.WriteUInt64(category.countOfProducts);

		buffer.WriteString(category.categoryName);
		buffer.WriteString(category.categoryDescription);
		buffer.WriteString(category.imageUrl);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		WriteToBuffer(category.categoryLabel, buffer);
#else
		buffer.WriteString(category.categoryId);
#endif

		buffer.WriteMarker(BufferIntegrityChecks::CategoryEnd);
	}

	void Commerce::WriteToBuffer(const CategoryLabel& categoryLabel, MemoryBuffer& buffer)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		buffer.WriteString(categoryLabel.value);
#else
		buffer.WriteString(categoryLabel.id);
#endif
	}

	void Commerce::WriteToBuffer(const ProductLabel& productLabel, MemoryBuffer& buffer)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		buffer.WriteString(productLabel.value);
#else
		buffer.WriteString(productLabel.id);
#endif
	}

	void Commerce::WriteToBuffer(const SkuLabel& skuLabel, MemoryBuffer& buffer)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		buffer.WriteString(skuLabel.value);
#else
		buffer.WriteString(skuLabel.id);
#endif
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	void Commerce::WriteToBuffer(const sce::Toolkit::NP::Commerce::ServiceEntitlementLabel& serviceEntitlementLabel, MemoryBuffer& buffer)
	{
		buffer.WriteString(serviceEntitlementLabel.value);
	}
#endif

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::SubCategory& subCategory, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::SubCategoryBegin);

		buffer.WriteString(subCategory.categoryName);

#if (SCE_ORBIS_SDK_VERSION < 0x04500000)
		// For SDK 4.0 write out the cartegory description which has been removed in later SDKs.
		buffer.WriteString(subCategory.categoryDescription);
#else
		// Write dummy category description in later SDKs.
		buffer.WriteString("");
#endif

		buffer.WriteString(subCategory.imageUrl);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		WriteToBuffer(subCategory.categoryLabel, buffer);
#else
		buffer.WriteString(subCategory.categoryId);
#endif

		buffer.WriteMarker(BufferIntegrityChecks::SubCategoryEnd);
	}

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::Product& product, bool hasDetails, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ProductBegin);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		WriteToBuffer(product.productLabel, buffer);
#else
		buffer.WriteString(product.productId);
#endif

		buffer.WriteString(product.productName);
		buffer.WriteString(product.imageUrl);
		
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		buffer.WriteBool(product.hasDetails);

		if(product.hasDetails == true )
		{
			WriteToBuffer(product.details, buffer);
		}
#else
		// Private support ticket 111065 - Some products, which have details, are incorrectly flagged with hasDetails being false.
		// If the first product has "hasDetail" true then all the rest of the product can be considered true. 
		// If first Product has is false then false for the rest. 
		buffer.WriteBool(hasDetails);

		if(hasDetails == true) // product.hasDetails == true )
		{
			WriteToBuffer(product.details, buffer);
		}
#endif

		buffer.WriteMarker(BufferIntegrityChecks::ProductEnd);
	}

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::ProductDetails& productDetails, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ProductDetailsBegin);

		Core::WriteToBuffer(productDetails.releaseDate,buffer);
		buffer.WriteString(productDetails.longDescription);
		buffer.WriteString(productDetails.spName);
		buffer.WriteString(productDetails.ratingSystemId);
		buffer.WriteString(productDetails.ratingImageUrl);

		buffer.WriteUInt64(NpToolkit2::Commerce::ProductDetails::MAX_RATING_SYSTEM_DESCRIPTORS);

		for(int i = 0; i < NpToolkit2::Commerce::ProductDetails::MAX_RATING_SYSTEM_DESCRIPTORS; i++)
		{
			WriteToBuffer(productDetails.ratingDescriptors[i], buffer);
		}
		
		buffer.WriteUInt64(productDetails.numSkus);

		for(int i = 0; i < productDetails.numSkus; i++)
		{
			WriteToBuffer(productDetails.skuinfo[i], buffer);
		}

		//The purchasabilityStatus property has been removed from the ProductDetails class, because it was never set. Instead, use the purchasabilityStatus property of the SkuInfo class
		buffer.WriteUInt32((UInt32)0); // productDetails.purchasabilityStatus);

		buffer.WriteUInt32(productDetails.starRatingsTotal);
		buffer.WriteDouble(productDetails.starRatingScore);

		buffer.WriteMarker(BufferIntegrityChecks::ProductDetailsEnd);
	}

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::SkuInfo& skuInfo, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::SkuInfoBegin);


		buffer.WriteUInt32((UInt32)skuInfo.type);
		buffer.WriteUInt32((UInt32)skuInfo.purchasabilityStatus);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		WriteToBuffer(skuInfo.label, buffer);
#else
		buffer.WriteString(skuInfo.id);
#endif
		
		buffer.WriteString(skuInfo.name);
		buffer.WriteString(skuInfo.price);

		buffer.WriteUInt64(skuInfo.intPrice);
		buffer.WriteUInt32(skuInfo.consumableUseCount);

		buffer.WriteMarker(BufferIntegrityChecks::SkuInfoEnd);
	}

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::RatingDescriptor& ratingDescriptor, MemoryBuffer& buffer)
	{
		buffer.WriteString(ratingDescriptor.name);
		buffer.WriteString(ratingDescriptor.imageUrl);
	}

	void Commerce::WriteToBuffer(const NpToolkit2::Commerce::ServiceEntitlement& serviceEntitlement, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::ServiceEntitlementBegin);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		WriteToBuffer(serviceEntitlement.entitlementLabel, buffer);
#else
		buffer.WriteString(serviceEntitlement.entitlementId);
#endif
		
		Core::WriteToBuffer(serviceEntitlement.createdDate, buffer);
		Core::WriteToBuffer(serviceEntitlement.expireDate, buffer);

		buffer.WriteInt64(serviceEntitlement.remainingCount);
		buffer.WriteUInt32(serviceEntitlement.consumedCount);

		buffer.WriteUInt32((UInt32)serviceEntitlement.type); // EntitlementType

		buffer.WriteMarker(BufferIntegrityChecks::ServiceEntitlementEnd);	
	}
}
