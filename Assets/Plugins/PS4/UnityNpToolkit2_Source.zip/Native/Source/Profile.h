#pragma once

#include "../Includes/PluginCommonIncludes.h"
#include "Core.h"

namespace NPT
{
	// Provide Profile PRX calls to NpToolkit Profile methods
	class Profile
	{
	private:

	public:

		static void WriteToBuffer(const NpToolkit2::UserProfile::RealName& npRealName, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::UserProfile::NpProfile& npProfile, MemoryBuffer& buffer);

	private:

	};
}





