
#include "NpUtils.h"

#include "Core.h"
#include "MainNPT.h"

namespace NPT
{
	DO_EXPORT( int, PrxSetTitleIdForDevelopment ) (SetTitleIdForDevelopmentManaged* managedRequest, APIResult* result)
	{
		return NpUtils::SetTitleIdForDevelopment(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplaySigninDialog ) (DisplaySigninDialogManaged* managedRequest, APIResult* result)
	{
		return NpUtils::DisplaySigninDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxCheckAvailablity ) (CheckAvailablityManaged* managedRequest, APIResult* result)
	{
		return NpUtils::CheckAvailablity(managedRequest, result);
	}

	DO_EXPORT( int, PrxCheckPlus ) (CheckPlusManaged* managedRequest, APIResult* result)
	{
		return NpUtils::CheckPlus(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetParentalControlInfo ) (GetParentalControlInfoManaged* managedRequest, APIResult* result)
	{
		return NpUtils::GetParentalControlInfo(managedRequest, result);
	}	

	DO_EXPORT( void, PrxNotifyPlusFeature ) (SceUserServiceUserId userId, uint64_t features, APIResult* result)
	{
		NpUtils::NotifyPlusFeature(userId, features, result);
	}	

	void SetTitleIdForDevelopmentManaged::CopyTo(NpToolkit2::NpUtils::Request::SetTitleIdForDevelopment &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		memcpy(destination.titleId.id, titleId, SCE_NP_TITLE_ID_LEN);   // SceNpTitleId
		strncpy(destination.titleSecretString, titleSecretString, titleSecretStringSize);
		destination.titleSecretStringSize = titleSecretStringSize;
	}

	void DisplaySigninDialogManaged::CopyTo(NpToolkit2::NpUtils::Request::DisplaySigninDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void CheckAvailablityManaged::CopyTo(NpToolkit2::NpUtils::Request::CheckAvailability &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void CheckPlusManaged::CopyTo(CheckPlusRequest &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.parameters = new SceNpCheckPlusParameter();
		memset(destination.parameters, 0, sizeof(SceNpCheckPlusParameter));
		destination.parameters->size = sizeof(SceNpCheckPlusParameter);
		destination.parameters->userId = userId;
		destination.parameters->features = features;
		
		destination.results = new SceNpCheckPlusResult();
		memset(destination.results, 0, sizeof(SceNpCheckPlusResult));
	}

	void GetParentalControlInfoManaged::CopyTo(GetParentalControlInfoRequest &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.userId = userId;
		destination.age = 0;

		destination.parentalControlInfo = new SceNpParentalControlInfo();
		memset(destination.parentalControlInfo, 0, sizeof(SceNpParentalControlInfo));
	}

	int NpUtils::SetTitleIdForDevelopment(SetTitleIdForDevelopmentManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::NpUtils::Request::SetTitleIdForDevelopment nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NpUtils::setTitleIdForDevelopment(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int NpUtils::DisplaySigninDialog(DisplaySigninDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::NpUtils::Request::DisplaySigninDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NpUtils::displaySigninDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int NpUtils::CheckAvailablity(CheckAvailablityManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::NpUtils::Request::CheckAvailability nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NpUtils::checkAvailability(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Special custom request that isn't part of the normal NpToolkit2 lib.
	// This uses the NP Request system instead to process the request asynchronously. 
	int NpUtils::CheckPlus(CheckPlusManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		// Dumpy response as this is a special custom request.
		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		CheckPlusRequest* nptRequest = new CheckPlusRequest();

		managedRequest->CopyTo(*nptRequest);

		if ( NpRequests::AddRequest(nptRequest, result) == false)
		{
			// result will already be filled in with error info
			delete nptResponse;
			return result->sceErrorCode;
		}

		int npRetCode = sceNpCheckPlus(nptRequest->internalRequestId, (SceNpCheckPlusParameter*)nptRequest->parameters, (SceNpCheckPlusResult*)nptRequest->results);

		int ret = NpRequests::RecordRequest(nptResponse, nptRequest, npRetCode, result);
		
		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			return ret;
		}

		SUCCESS_RESULT(result);

		return ret;
	}

	int NpUtils::GetParentalControlInfo(GetParentalControlInfoManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		// Dumpy response as this is a special custom request.
		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		GetParentalControlInfoRequest* nptRequest = new GetParentalControlInfoRequest();

		managedRequest->CopyTo(*nptRequest);

		if ( NpRequests::AddRequest(nptRequest, result) == false)
		{
			// result will already be filled in with error info
			delete nptResponse;
			return result->sceErrorCode;
		}

		int npRetCode = sceNpGetParentalControlInfoA(nptRequest->internalRequestId, nptRequest->userId, &nptRequest->age, nptRequest->parentalControlInfo);

		int ret = NpRequests::RecordRequest(nptResponse, nptRequest, npRetCode, result);
		
		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			return ret;
		}

		SUCCESS_RESULT(result);

		return ret;
	}

	void NpUtils::NotifyPlusFeature(SceUserServiceUserId userId, uint64_t features, APIResult* result)
	{
		SceNpNotifyPlusFeatureParameter notifyParams;

		memset(&notifyParams, 0x0, sizeof(SceNpNotifyPlusFeatureParameter));
		notifyParams.size = sizeof(SceNpNotifyPlusFeatureParameter);
		notifyParams.userId = userId;
		notifyParams.features = features;

		int ret = sceNpNotifyPlusFeature(&notifyParams);
		if (ret != 0)
		{
			SCE_ERROR_RESULT(result, ret);
			return;
		}

		SUCCESS_RESULT(result);
	}

	// Marshal responses
	void NpUtils::MarshalUserStateChange(NptUserStateChangeResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::UserStateChangeBegin);

		const NptUserStateChange* userStateChange = response->get();

		buffer.WriteInt32(userStateChange->userId);
		buffer.WriteInt32((Int32)userStateChange->currentSignInState);
		buffer.WriteInt32((Int32)userStateChange->currentLogInState);
		buffer.WriteInt32((Int32)userStateChange->stateChanged);

		buffer.WriteMarker(BufferIntegrityChecks::UserStateChangeEnd);

		SUCCESS_RESULT(result);
	}

	// Custom Requests

	CheckPlusRequest::CheckPlusRequest() : NpRequest(NpToolkit2::Core::ServiceType::npUtils, FunctionTypeExtended::npUtilsCheckPlus)
	{

	}

	MemoryBuffer& CheckPlusRequest::MarshalResult()
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();		
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::CheckPlusBegin);

		buffer.WriteBool(results->authorized);

		buffer.WriteMarker(BufferIntegrityChecks::CheckPlusEnd);

		buffer.FinishResponseWrite();

		return buffer;
	}

	void CheckPlusRequest::Cleanup()
	{
		delete parameters;
		delete results;
	}

	GetParentalControlInfoRequest::GetParentalControlInfoRequest() : NpRequest(NpToolkit2::Core::ServiceType::npUtils, FunctionTypeExtended::npUtilsGetParentalControlInfo)
	{

	}

	MemoryBuffer& GetParentalControlInfoRequest::MarshalResult()
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();		
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::GetParentalControlInfoBegin);

		buffer.WriteInt32((Int32)age);

		buffer.WriteBool(parentalControlInfo->contentRestriction);
		buffer.WriteBool(parentalControlInfo->chatRestriction);
		buffer.WriteBool(parentalControlInfo->ugcRestriction);

		buffer.WriteMarker(BufferIntegrityChecks::GetParentalControlInfoEnd);

		buffer.FinishResponseWrite();

		return buffer;
	}

	void GetParentalControlInfoRequest::Cleanup()
	{
		delete parentalControlInfo;
	}
}
