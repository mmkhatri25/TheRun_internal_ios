
#include "NpRequests.h"

namespace NPT
{
	
	DO_EXPORT( bool, PrxPollFirstRequest )()
	{
		return NpRequests::PollFirstRequest();
	}

	std::map<int, NpRequest *> NpRequests::m_RequestList;
	UInt32 NpRequests::nextRequestId = g_customNpRequestIdStart;
	ManagedEventCallback NpRequests::s_npRequestEventCallback = NULL;
	Mutex NpRequests::mutex;
	SceKernelCpumask NpRequests::s_currentCpuMask = SCE_KERNEL_CPUMASK_USER_ALL & ~0x3;	// all cores excluding 0 (update) and 1 (render)

	void NpRequests::WakeUpManagedThread()
	{
		if ( s_npRequestEventCallback != NULL )
		{
			s_npRequestEventCallback();
		}
	}

	void NpRequests::SetCurrentCpuMask(SceKernelCpumask mask)
	{
		s_currentCpuMask = mask;
	}

	int NpRequests::CreateRequestId(bool async, APIResult* result)
	{
		int requestid = 0;

		if(async == true )
		{
			SceNpCreateAsyncRequestParameter requestParam;
			memset(&requestParam, 0, sizeof(requestParam));
			requestParam.size = sizeof(requestParam);
			requestParam.cpuAffinityMask = s_currentCpuMask;
			requestParam.threadPriority = SCE_KERNEL_PRIO_FIFO_DEFAULT;

			requestid = sceNpCreateAsyncRequest(&requestParam);
		}
		else
		{
			requestid = sceNpCreateRequest();
		}

		if (requestid < 0)
		{
			switch(requestid)
			{
				case SCE_NP_ERROR_INVALID_ARGUMENT:		// Argument is invalid
				case SCE_NP_ERROR_OUT_OF_MEMORY:		// Not enough free memory
				case SCE_NP_ERROR_INVALID_SIZE:			// pParam->size is invalid
				case SCE_NP_ERROR_REQUEST_MAX:			// Created more than 32 requests at one time.
				default:
					SCE_ERROR_RESULT(result, requestid);
					break;
			}
			DeleteRequestId(requestid, result);
			return 0;
		}

		SUCCESS_RESULT(result);

		return requestid;
	}

	void NpRequests::DeleteRequestId(int requestid, APIResult* result)
	{
		if (requestid > 0) 
		{
			int retDelete = sceNpDeleteRequest(requestid);
			if(retDelete < 0)
			{
				switch(retDelete)
				{
					case SCE_NP_ERROR_INVALID_ARGUMENT:			// reqId is not a positive number (>0)
					case SCE_NP_ERROR_REQUEST_NOT_FOUND:		// Request specified for reqId does not exist
					default:
						SCE_ERROR_RESULT(result, retDelete);
						break;
				}
			}		

			SUCCESS_RESULT(result);

			return;
		}

		ERROR_RESULT(result, "DeleteRequest : requestid should be greater than 0");
	}

	bool NpRequests::AddRequest(NpRequest* request, APIResult* result)
	{
		mutex.Lock();

		request->internalRequestId = NpRequests::CreateRequestId(request->async, result);

		if ( result->apiResult != Success )
		{
			mutex.UnLock();
			return false;
		}

		request->managedRequestId = nextRequestId;
		nextRequestId++;

		m_RequestList.insert(std::pair<int,NpRequest *>(request->managedRequestId, request) );

		mutex.UnLock();
		return true;
	}

	bool NpRequests::RemoveRequest(NpRequest *request, APIResult* result)
	{
		mutex.Lock();
		m_RequestList.erase(request->managedRequestId);

		DeleteRequestId(request->internalRequestId, result);

		request->Cleanup();

		mutex.UnLock();
		if ( result->apiResult != Success )
		{
			return false;
		}

		return true;
	}

    bool NpRequests::IsPendingCustomRequest(UInt32 npRequestID)
	{
        auto it = m_RequestList.find(npRequestID);

        return it != m_RequestList.end();
    }

	int NpRequests::RecordRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpRequest* request, int npReturnCode, APIResult* apiResult)
	{
		// For async requests the npReturnCode should be a npRequestId returned from the method. If it
		// is less than 0 it means an error has occured.
		// For synchronous requests the npReturnCode might be an error code or 0 for success.
		// either way the request needs to be removed from the list and the error code returned.
		if (npReturnCode < 0) 
		{
			SCE_ERROR_RESULT(apiResult, npReturnCode);

			NpRequests::RemoveRequest(request, apiResult); // Will delete any parameters and results data
			delete request;
			return npReturnCode;
		}

		// Either a valid toolkie request id (for async calls) has been asigned or a return code of success has occured.
		// Add the request to the map.
		ResponseMap::AddCustomRequest(responsePtr, *request, request->managedRequestId);

		// If it's an synchronous call then the results will already have been fetched, so process the results here.
		if ( request->async == false )
		{
			// Get the results out.
			MemoryBuffer& buffer = request->MarshalResult();

			ResponseMap::AddMemoryResultsBuffer(buffer, request->managedRequestId, (NpToolkit2::Core::FunctionType)request->getFunctionType());

			NpRequests::RemoveRequest(request, apiResult);

			Int32 requestId = request->managedRequestId;

			delete request;

			return requestId;
		}

		// For async requests, the results aren't ready yet, so notify the npRequest polling thread to start polling for results.
		NpRequests::WakeUpManagedThread();
		return request->managedRequestId;
	}

	bool NpRequests::PollFirstRequest()
	{
		APIResult apiResult;
		int requestResult = 0;
		
		mutex.Lock();

		if ( m_RequestList.size() == 0 ) return false;

		auto it = m_RequestList.begin();
		if (it != m_RequestList.end())
		{
			NpRequest *request = it->second;

			int retPoll = sceNpPollAsync(request->internalRequestId, &requestResult);

			if (retPoll != SCE_NP_POLL_ASYNC_RET_RUNNING) 		
			{
				// Process the results here.
				// The retPoll should be SCE_NP_POLL_ASYNC_RET_FINISHED. 
				// Even if its not process the results here anyway as the request may have failed in some way.
				// It's still important to record the results so the error code etc can be retrieved by the C# code.
				MemoryBuffer& buffer = request->MarshalResult();

				CompletedAsyncEvents::AddCustomRequest(request->managedRequestId, request->userId, requestResult, request->getServiceType(), (FunctionTypeExtended)request->getFunctionType(), buffer);

				NpRequests::RemoveRequest(request, &apiResult);
				delete request;

				mutex.UnLock();
				return true;
			}
		}

		mutex.UnLock();
		return false;
	}

	NpRequest::NpRequest(NpToolkit2::Core::ServiceType service, FunctionTypeExtended function) : NpToolkit2::Core::RequestBase( service, (NpToolkit2::Core::FunctionType)function),
		internalRequestId(0),
		managedRequestId(0)
	{

	}

	NpRequest::~NpRequest()
	{

	}
}