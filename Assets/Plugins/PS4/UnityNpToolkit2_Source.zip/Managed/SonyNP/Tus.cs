﻿using System;
using System.Runtime.InteropServices;


namespace Sony
{
	namespace NP
	{

		/// <summary>
		/// TUS service related functionality.
		/// </summary>
		public class Tus
		{
			#region DLL Imports

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusSetVariables(SetVariablesRequest request, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusGetVariables(GetVariablesRequest request, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusAddToAndGetVariable(AddToAndGetVariableRequest request, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusSetData(SetDataRequest request, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusGetData(GetDataRequest request, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern int PrxTusDeleteData(DeleteDataRequest request, out APIResult result);

            // SDK 5.0 addtional features
            [DllImport("UnityNpToolkit2")]
            private static extern int PrxTusTryAndSetVariable(TryAndSetVariableRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxTusGetFriendsVariable(GetFriendsVariableRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxTusGetUsersVariable(GetUsersVariableRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxTusGetUsersDataStatus(GetUsersDataStatusRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxTusGetFriendsDataStatus(GetFriendsDataStatusRequest request, out APIResult result);

			#endregion

			#region General
			/// <summary>
			/// 16 character TUS virtual user Id
			/// </summary>
		    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public struct VirtualUserID  // Maps to SceNpTusVirtualUserId
			{
				/// <summary>
				/// Maximum length of the virtual id
				/// </summary>
				public const int NP_ONLINEID_MAX_LENGTH = 16;

				[MarshalAs(UnmanagedType.ByValTStr, SizeConst = NP_ONLINEID_MAX_LENGTH+1)]
				internal string name;

				/// <summary>
				/// Display representation of an online user
				/// </summary>
				public string Name
				{
					get { return name; }
					set
					{
						if (value.Length > NP_ONLINEID_MAX_LENGTH)
						{
							throw new NpToolkitException("VirtualUserID can't be more than " + NP_ONLINEID_MAX_LENGTH + " characters.");
						}

						name = value;
					}
				}

				// Read data from PRX marshaled buffer
				internal void Read(MemoryBuffer buffer)
				{
					buffer.ReadString(ref name);
				}

				/// <summary>
				/// Returns the OnlineId as a string, with a maximum of 16 characters.
				/// </summary>
				/// <returns>The OnLineId name</returns>
				public override string ToString()
				{
					return name;
				}
			};

			/// <summary>
			/// Represents a TUS (title user storage) variable
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public struct VariableInput
			{
				internal Int64 varValue;
				internal Int32 slotId;

				/// <summary>
				/// The TUS variable value
				/// </summary>
				public Int64 Value
				{
					get { return varValue; }
					set { varValue = value; }
				}

				/// <summary>
				/// The slot that the variable belongs to
				/// </summary>
				public Int32 SlotId
				{
					get { return slotId; }
					set { slotId = value; }
				}
			}

            /// <summary>
            /// Represents a TUS user on the server.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public struct UserInput
			{
                internal VirtualUserID virtualId;
                internal Core.NpAccountId realId;

                [MarshalAs(UnmanagedType.I1)]
                internal bool isVirtual;

                /// <summary>
                /// The Virtual user id. 
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the <see cref="IsVirtual"/> is false.</exception>
                public VirtualUserID VirtualId
                {
                    get 
                    {
                        if (isVirtual == false)
                        {
                            throw new NpToolkitException("The User is not a virtual user.");
                        }

                        return virtualId; 
                    }

                    set { virtualId = value; isVirtual = true; }
                }

                /// <summary>
                /// The Real user id. 
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the <see cref="IsVirtual"/> is true.</exception>
                public Core.NpAccountId RealId
                {
                    get 
                    {
                        if (isVirtual == false)
                        {
                            throw new NpToolkitException("The User is not a real user.");
                        }

                        return realId; 
                    }
                    set { realId = value; isVirtual = false; }
                }

                /// <summary>
                /// Returns if the user is a virtual user or not. This is set when either <see cref="VirtualId"/> or <see cref="RealId"/> value is changed.
                /// </summary>
                public bool IsVirtual
                {
                    get { return isVirtual; }
                }

                /// <summary>
                /// Create a Virtual user
                /// </summary>
                /// <param name="id">The virtual id of the user.</param>
                public UserInput(VirtualUserID id)
                {
                    realId = 0;
                    virtualId = id; 
                    isVirtual = true;
                }

                /// <summary>
                /// Create a real user
                /// </summary>
                /// <param name="id">The real account id of the user.</param>
                public UserInput(Core.NpAccountId id)
                {
                    realId = id;
                    virtualId = new VirtualUserID();
                    isVirtual = false;
                }
	        };


			/// <summary>
			/// Common data members for TUS variable
			/// </summary>
			public class NpVariableBase
			{
				internal bool hasData;
				internal DateTime lastChangedDate;
				internal Int64 variable;
				internal Int64 oldVariable;
				internal Core.NpAccountId ownerAccountId;
				internal Core.NpAccountId lastChangedAuthorAccountId;

				/// <summary>
				/// Flag indicating whether a value has been set.
				/// </summary>
				public bool HasData { get { return hasData; } }

				/// <summary>
				/// Last update date
				/// </summary>
				public DateTime LastChangedDate { get { return lastChangedDate; } }

				/// <summary>
				/// Currently set value
				/// </summary>
				public Int64 Variable { get { return variable; } }

				/// <summary>
				/// Previously set value
				/// </summary>
				public Int64 OldVariable { get { return oldVariable; } }

				/// <summary>
				/// Account ID of the owner
				/// </summary>
				public Core.NpAccountId OwnerAccountId { get { return ownerAccountId; } }

				/// <summary>
				/// Account ID of the user who made the last update
				/// </summary>
				public Core.NpAccountId LastChangedAuthorAccountId { get { return lastChangedAuthorAccountId; } }

				// Read data from PRX marshaled buffer
				internal void ReadBase(MemoryBuffer buffer)
				{
					hasData = buffer.ReadBool();
					lastChangedDate = Core.ReadRtcTick(buffer);
					variable = buffer.ReadInt64();
					oldVariable = buffer.ReadInt64();
					ownerAccountId.Read(buffer);
					lastChangedAuthorAccountId.Read(buffer);
				}
			}

			/// <summary>
			/// Represents a TUS variable
			/// </summary>
			public class NpVariable : NpVariableBase
			{
				internal Core.OnlineID ownerId;
				internal Core.OnlineID lastChangedAuthorId;

				/// <summary>
				/// Online ID of the owner
				/// </summary>
				public Core.OnlineID OwnerId { get { return ownerId; } }

				/// <summary>
				/// Online ID of the user who made the last update
				/// </summary>
				public Core.OnlineID LastChangedAuthorId { get { return lastChangedAuthorId; } }

				// Read data from PRX marshaled buffer
				internal void Read(MemoryBuffer buffer)
				{
					ReadBase(buffer);

					ownerId = new Core.OnlineID();
					ownerId.Read(buffer);

					lastChangedAuthorId = new Core.OnlineID();
					lastChangedAuthorId.Read(buffer);
				}
			}

			/// <summary>
			/// Represents a TUS variable (for cross-platform use)
			/// </summary>
			public class NpVariableForCrossSave : NpVariableBase
			{
				internal Core.NpId ownerId;
				internal Core.NpId lastChangedAuthorId;

				/// <summary>
				/// Owner
				/// </summary>
				public Core.NpId OwnerId { get { return ownerId; } }

				/// <summary>
				/// Last updated by
				/// </summary>
				public Core.NpId LastChangedAuthorId { get { return lastChangedAuthorId; } }

				// Read data from PRX marshaled buffer
				internal void Read(MemoryBuffer buffer)
				{
					ReadBase(buffer);

					ownerId.Read(buffer);
					lastChangedAuthorId.Read(buffer);
				}
			}

            #region Obsolete
			/// <summary>
			/// Common data members for TUS status
			/// </summary>
            [System.Obsolete("Use TusDataStatusBase instead.")]
			public class NpTusDataStatusBase
			{
				/// <summary>
				/// Flag indicating whether a value has been set.
				/// </summary>
				public bool HasData { get { return false; } }

				/// <summary>
				/// Last update date
				/// </summary>
				public DateTime LastChangedDate { get { return new DateTime(); } }

				/// <summary>
				/// The TUS data
				/// </summary>
				public byte[] Data { get { return null; } }

				/// <summary>
				///  The TUS sumplementary info
				/// </summary>
				public byte[] SupplementaryInfo { get { return null; } }

				/// <summary>
				/// Account ID of the owner
				/// </summary>
				public Core.NpAccountId OwnerAccountId { get { return 0; } }

				/// <summary>
				/// Account ID of the user who made the last update
				/// </summary>
				public Core.NpAccountId LastChangedAuthorAccountId { get { return 0; } }
			}

			/// <summary>
			/// Represents the status of TUS data
			/// </summary>
            [System.Obsolete("Use TusDataStatusForCrossSave instead.")]
			public class NpTusDataStatus : NpTusDataStatusBase
			{
				/// <summary>
				/// Online ID of the owner
				/// </summary>
				public Core.OnlineID OwnerId { get { return new Core.OnlineID(); } }

				/// <summary>
				/// Online ID of the user who made the last update
				/// </summary>
				public Core.OnlineID LastChangedAuthorId { get { return new Core.OnlineID(); } }
			}

			/// <summary>
			/// Represents  the status of TUS data (for cross-platform use)
			/// </summary>
            [System.Obsolete("Use TusDataStatusForCrossSave instead.")]
			public class NpTusDataStatusForCrossSave : NpTusDataStatusBase
			{
				/// <summary>
				/// Owner
				/// </summary>
				public Core.NpId OwnerId { get { return new Core.NpId(); } }

				/// <summary>
				/// Last updated by
				/// </summary>
				public Core.NpId LastChangedAuthorId { get { return new Core.NpId(); } }
			}
            #endregion

            /// <summary>
			/// Common data members for TUS status
			/// </summary>
			public class TusDataStatusBase
			{
				internal bool hasData;
				internal DateTime lastChangedDate;
				internal byte[] supplementaryInfo;

				/// <summary>
				/// Indicates whether a slot has TUS data associated with it. The data is not provided in this class. If required, requested it using <see cref="GetData"/>
				/// </summary>
				public bool HasData { get { return hasData; } }

				/// <summary>
                /// The date of the last change made to the TUS data.
				/// </summary>
				public DateTime LastChangedDate { get { return lastChangedDate; } }

				/// <summary>
                /// The supplementary information for the TUS Data.
				/// </summary>
				public byte[] SupplementaryInfo { get { return supplementaryInfo; } }

				// Read data from PRX marshaled buffer
				internal void ReadBase(MemoryBuffer buffer)
				{
					hasData = buffer.ReadBool();
					lastChangedDate = Core.ReadRtcTick(buffer);
					buffer.ReadData(ref supplementaryInfo);
				}
			}

            /// <summary>
            /// Represents the data status of of a TUS data record on the server.
            /// </summary>
            public class TusDataStatus : TusDataStatusBase
			{
				internal Core.OnlineUser owner;
                internal Core.OnlineUser lastChangedBy;

				/// <summary>
                /// The owner of the TUS data.
				/// </summary>
                public Core.OnlineUser Owner { get { return owner; } }

				/// <summary>
                /// The user who last modified the TUS data.
				/// </summary>
                public Core.OnlineUser LastChangedBy { get { return lastChangedBy; } }

				// Read data from PRX marshaled buffer
				internal void Read(MemoryBuffer buffer)
				{
					ReadBase(buffer);

                    owner = new Core.OnlineUser();
					owner.Read(buffer);

                    lastChangedBy = new Core.OnlineUser();
					lastChangedBy.Read(buffer);
				}
			}

            /// <summary>
            /// Represents the data status of a TUS data record that is compatibile with multiple PlayStation platforms.
            /// </summary>
            public class TusDataStatusForCrossSave : TusDataStatusBase
            {
                internal Core.NpAccountId ownerAccountId;
                internal Core.NpAccountId lastChangedByAccountId;
                internal Core.NpId ownerNpId;
                internal Core.NpId lastChangedByNpId;

                /// <summary>
                /// The Account ID of the user who owns the TUS data.
                /// </summary>
                public Core.NpAccountId OwnerAccountId { get { return ownerAccountId; } }

                /// <summary>
                /// The Account ID of the user who last modified the TUS data.
                /// </summary>
                public Core.NpAccountId LastChangedByAccountId { get { return lastChangedByAccountId; } }

                /// <summary>
                /// The Np ID of the user who owns the TUS data. 
                /// </summary>
                public Core.NpId OwnerNpId { get { return ownerNpId; } }

                /// <summary>
                /// The Np ID of the user who last modified the TUS data.
                /// </summary>
                public Core.NpId LastChangedByNpId { get { return lastChangedByNpId; } }

                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    ReadBase(buffer);

                    ownerAccountId.Read(buffer);
                    lastChangedByAccountId.Read(buffer);
                    ownerNpId.Read(buffer);
                    lastChangedByNpId.Read(buffer);
                }
            }

			#endregion

			#region Requests
			
			/// <summary>
			/// Parameters required for setting a specified users TUS variables
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
			public class SetVariablesRequest : RequestBase
			{
				/// <summary>
				/// Maximum size of the <see cref="Vars"/> array.
				/// </summary>
				public const int MAX_VARIABLE_SLOTS = 256;

                internal UserInput tusUser;

				internal UInt64 numVars;  

				[MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_VARIABLE_SLOTS)]
                VariableInput[] variables = new VariableInput[MAX_VARIABLE_SLOTS];

				/// <summary>
				/// The TUS variables to update
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_VARIABLE_SLOTS"/>.</exception>
                public VariableInput[] Vars
				{
					get 
					{
						if (numVars == 0) return null;

                        VariableInput[] output = new VariableInput[numVars];

                        Array.Copy(variables, output, (int)numVars);

						return output;
					}
					set
					{
						if (value != null)
						{
							if (value.Length > MAX_VARIABLE_SLOTS)
							{
								throw new NpToolkitException("The size of the array is larger than " + MAX_VARIABLE_SLOTS);
							}

                            value.CopyTo(variables, 0);
							numVars = (UInt64)value.Length;
						}
						else
						{
							numVars = 0;
						}
					}
				}

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

                #region Obsolete
                /// <summary>
				/// The account of the user to set the variables for
				/// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
				public Core.NpAccountId TargetUser
				{
                    get { return 0; }
					set {}
				}

				/// <summary>
				/// Identifier of a virtual user
				/// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
				public VirtualUserID VirtualUserID
				{
                    get { return new VirtualUserID(); }
                    set { }
				}

				/// <summary>
				/// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
				/// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
				public bool IsVirtualUser
				{
					get { return false; }
				}
                #endregion

                /// <summary>
				/// Initializes a new instance of the <see cref="SetVariablesRequest"/> class.
				/// </summary>
				public SetVariablesRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusSetVariables)
				{

				}
			}

			/// <summary>
			/// Parameters required for getting a specified users TUS variables
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetVariablesRequest : RequestBase
			{
				/// <summary>
				/// Maximum size of the <see cref="SlotIds"/> array.
				/// </summary>
				public const int MAX_VARIABLE_SLOTS = 256;

                internal UserInput tusUser;

				internal UInt64 numSlots;

				[MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_VARIABLE_SLOTS)]
				internal Int32[] slotIds = new Int32[MAX_VARIABLE_SLOTS];

				[MarshalAs(UnmanagedType.I1)]
				internal bool forCrossSave;

				/// <summary>
				/// The IDs of the slots to retrieve variables from
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_VARIABLE_SLOTS"/>.</exception>
				public Int32[] SlotIds
				{
					get 
					{
						if (numSlots == 0) return null;

						Int32[] output = new Int32[numSlots];

						Array.Copy(slotIds, output, (int)numSlots);

						return output;
					}
					set
					{
						if (value != null)
						{
							if (value.Length > MAX_VARIABLE_SLOTS)
							{
								throw new NpToolkitException("The size of the array is larger than " + MAX_VARIABLE_SLOTS);
							}

							value.CopyTo(slotIds, 0);
							numSlots = (UInt64)value.Length;
						}
						else
						{
							numSlots = 0;
						}
					}
				}

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

                #region Obsolete
                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
                public Core.NpAccountId TargetUser
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// Identifier of a virtual user
                /// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
                public VirtualUserID VirtualUserID
                {
                    get { return new VirtualUserID(); }
                    set { }
                }

                /// <summary>
                /// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
                /// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
                public bool IsVirtualUser
                {
                    get { return false; }
                }
                #endregion

				/// <summary>
				/// Initializes a new instance of the <see cref="SetVariablesRequest"/> class.
				/// </summary>
				public GetVariablesRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetVariables)
				{

				}
			}

			/// <summary>
			/// Used to prevent data conflicts on the TUS server
			/// </summary>
			public struct DataContention
			{
				internal UInt64 lastChangedDateTicks;  // is stored in SceRtcTick format
				internal Core.NpAccountId requiredLastChangeUser;

				/// <summary>
				///  The date and time for conflict prevention. Processing is only executed when the time of the TUS data's last update, which is registered on the server, is identical with or older
				///  than the specified time. When no TUS data is registered on the server, no processing is performed. Specify 0 if no comparison is necessary.
				/// </summary>
				public DateTime LastChangedDate
				{
					get
					{
						return Core.RtcTicksToDateTime(lastChangedDateTicks);
					}
					set
					{
						lastChangedDateTicks = Core.DateTimeToRtcTicks(value);
					}
				}

				/// <summary>
				/// The account id of the updates author for conflict prevention. Processing is only executed when the author of the TUS data's last update, which is registered on the server, 
				/// is identical with the specified account id. When no TUS data is registered on the server, processing is not performed. Set this value to 0 if no comparison is necessary.
				/// </summary>
				public Core.NpAccountId RequiredLastChangeUser
				{
					get { return requiredLastChangeUser; }
					set { requiredLastChangeUser = value; }
				}
			}

			/// <summary>
			/// Parameters required for adding to a specified users TUS variable
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class AddToAndGetVariableRequest : RequestBase
			{
                internal UserInput tusUser;

                internal VariableInput var;

				internal DataContention dataContention;

				[MarshalAs(UnmanagedType.I1)]
				internal bool forCrossSave;

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

				/// <summary>
				/// The TUS variable to update
				/// </summary>
                public VariableInput Var
				{
					get { return var; }
					set { var = value; }
				}

				/// <summary>
				/// Prevention of data contention
				/// </summary>
				public DataContention DataContention
				{
					get { return dataContention; }
					set { dataContention = value; }
				}

				
				/// <summary>
				/// For compatibility with older platforms, set this when performing cross save actions
				/// </summary>
				public bool ForCrossSave
				{
					get { return forCrossSave; }
					set { forCrossSave = value; }
				}

                #region Obsolete
                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
                public Core.NpAccountId TargetUser
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// Identifier of a virtual user
                /// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
                public VirtualUserID VirtualUserID
                {
                    get { return new VirtualUserID(); }
                    set { }
                }

                /// <summary>
                /// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
                /// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
                public bool IsVirtualUser
                {
                    get { return false; }
                }
                #endregion

				/// <summary>
				/// Initializes a new instance of the <see cref="AddToAndGetVariableRequest"/> class.
				/// </summary>
				public AddToAndGetVariableRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusAddToAndGetVariable)
				{
					dataContention.lastChangedDateTicks = 0;
					dataContention.requiredLastChangeUser = 0;
				}
			}

			/// <summary>
			/// Parameters required for setting a specified users TUS binary data
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class SetDataRequest : RequestBase
			{
				/// <summary>
				/// Maximum size of the <see cref="SupplementaryInfo"/> array.
				/// </summary>
				public const int NP_TUS_DATA_INFO_MAX_SIZE = 384;

                internal UserInput tusUser;

				[MarshalAs(UnmanagedType.LPArray)]
				internal byte[] data;
				internal UInt64 dataSize;

				internal UInt64 supplementaryInfoSize;

				[MarshalAs(UnmanagedType.ByValArray, SizeConst = NP_TUS_DATA_INFO_MAX_SIZE)]
				internal byte[] supplementaryInfo = new byte[NP_TUS_DATA_INFO_MAX_SIZE];

				internal DataContention dataContention;

				internal Int32 slotId;

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

				/// <summary>
				/// The TUS data to update
				/// </summary>
				public byte[] Data
				{
					get { return data; }
					set 
					{
						data = value;
						dataSize = (value != null) ? (UInt64)value.Length : 0;
					}
				}

				/// <summary>
				/// Supplementary Information for the  TUS Data
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="NP_TUS_DATA_INFO_MAX_SIZE"/>.</exception>
				public byte[] SupplementaryInfo
				{
					get 
					{
						if (supplementaryInfoSize == 0) return null;

						byte[] output = new byte[supplementaryInfoSize];

						Array.Copy(supplementaryInfo, output, (int)supplementaryInfoSize);

						return output;
					}
					set
					{
						if (value != null)
						{
							if (value.Length > NP_TUS_DATA_INFO_MAX_SIZE)
							{
								throw new NpToolkitException("The size of the array is larger than " + NP_TUS_DATA_INFO_MAX_SIZE);
							}

							value.CopyTo(supplementaryInfo, 0);
							supplementaryInfoSize = (UInt64)value.Length;
						}
						else
						{
							supplementaryInfoSize = 0;
						}
					}
				}

				/// <summary>
				/// The ID of the slot that the data belongs to
				/// </summary>
				public Int32 SlotId
				{
					get { return slotId; }
					set { slotId = value; }
				}

				/// <summary>
				/// Prevention of data contention
				/// </summary>
				public DataContention DataContention
				{
					get { return dataContention; }
					set { dataContention = value; }
				}

                #region Obsolete
                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
                public Core.NpAccountId TargetUser
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// Identifier of a virtual user
                /// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
                public VirtualUserID VirtualUserID
                {
                    get { return new VirtualUserID(); }
                    set { }
                }

                /// <summary>
                /// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
                /// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
                public bool IsVirtualUser
                {
                    get { return false; }
                }
                #endregion

				/// <summary>
				/// Initializes a new instance of the <see cref="SetVariablesRequest"/> class.
				/// </summary>
				public SetDataRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusSetData)
				{

				}
			}

			/// <summary>
			/// Parameters required for getting a specified users TUS binary data
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetDataRequest : RequestBase
			{
                internal UserInput tusUser;

				internal Int32 slotId;

				[MarshalAs(UnmanagedType.I1)]
				internal bool forCrossSave;

				[MarshalAs(UnmanagedType.I1)]
				internal bool retrieveStatusOnly;

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

				/// <summary>
				/// The ID of the slot that the data belongs to
				/// </summary>
				public Int32 SlotId
				{
					get { return slotId; }
					set { slotId = value; }
				}

				/// <summary>
				/// For compatibility with older platforms, set this when performing cross save actions
				/// </summary>
				public bool ForCrossSave
				{
					get { return forCrossSave; }
					set { forCrossSave = value; }
				}		

				/// <summary>
				/// If set to true, only the data size in status is retrieved. The data buffer will be empty
				/// </summary>
				public bool RetrieveStatusOnly
				{
					get { return retrieveStatusOnly; }
					set { retrieveStatusOnly = value; }
				}

                #region Obsolete
                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
                public Core.NpAccountId TargetUser
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// Identifier of a virtual user
                /// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
                public VirtualUserID VirtualUserID
                {
                    get { return new VirtualUserID(); }
                    set { }
                }

                /// <summary>
                /// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
                /// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
                public bool IsVirtualUser
                {
                    get { return false; }
                }
                #endregion

				/// <summary>
				/// Initializes a new instance of the <see cref="SetVariablesRequest"/> class.
				/// </summary>
				public GetDataRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetData)
				{

				}
			}

			/// <summary>
			/// Parameters required for deleting a specified users TUS binary data
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class DeleteDataRequest : RequestBase
			{
				/// <summary>
				/// Maximum size of the <see cref="SlotIds"/> array.
				/// </summary>
				public const int MAX_DATA_SLOTS = 64;

                internal UserInput tusUser;

				internal UInt64 numSlots;

				[MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_DATA_SLOTS)]
				Int32[] slotIds = new Int32[MAX_DATA_SLOTS];

                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

				/// <summary>
				/// The IDs of the slots that you want to delete
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_DATA_SLOTS"/>.</exception>
				public Int32[] SlotIds
				{
					get
					{
						if (numSlots == 0) return null;

						Int32[] output = new Int32[numSlots];

						Array.Copy(slotIds, output, (int)numSlots);

						return output;
					}
					set
					{
						if (value != null)
						{
							if (value.Length > MAX_DATA_SLOTS)
							{
								throw new NpToolkitException("The size of the array is larger than " + MAX_DATA_SLOTS);
							}

							value.CopyTo(slotIds, 0);
							numSlots = (UInt64)value.Length;
						}
						else
						{
							numSlots = 0;
						}
					}
				}

                #region Obsolete
                /// <summary>
                /// The account of the user to set the variables for
                /// </summary>
                [System.Obsolete("TargetUser is deprecated, please use TusUser instead.")]
                public Core.NpAccountId TargetUser
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// Identifier of a virtual user
                /// </summary>
                [System.Obsolete("VirtualUserID is deprecated, please use TusUser instead.")]
                public VirtualUserID VirtualUserID
                {
                    get { return new VirtualUserID(); }
                    set { }
                }

                /// <summary>
                /// A flag that specifies whether this update is for a virtual user. This is atomatically set depending on if <see cref="TargetUser"/> or <see cref="VirtualUserID"/> is set.
                /// </summary>
                [System.Obsolete("IsVirtualUser is deprecated, please use TusUser instead.")]
                public bool IsVirtualUser
                {
                    get { return false; }
                }
                #endregion

				/// <summary>
				/// Initializes a new instance of the <see cref="DeleteDataRequest"/> class.
				/// </summary>
				public DeleteDataRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusDeleteData)
				{

				}
			}

            /// <summary>
            /// Represents the type of comparison to make against the TUS data on the server.
            /// </summary>
            public enum TryAndSetCompareOperator
            {
                /// <summary> Indicates that no operator type has been specified. </summary>
                None = 0,
                /// <summary> Checks if the current value on the TUS server is equal to <see cref="TryAndSetVariableRequest.VarToUpdate"/> </summary>
                Equal = 1, //SCE_NP_TUS_OPETYPE_EQUAL
                /// <summary> Checks if the current value on the TUS server is not equal to <see cref="TryAndSetVariableRequest.VarToUpdate"/></summary>
                NotEqual, //SCE_NP_TUS_OPETYPE_NOT_EQUAL
                /// <summary> Checks if the current value on the TUS server is greater than <see cref="TryAndSetVariableRequest.VarToUpdate"/></summary>
                GreaterThan, //SCE_NP_TUS_OPETYPE_GREATER_THAN
                /// <summary> Checks if the current value on the TUS server is greater than or equal to <see cref="TryAndSetVariableRequest.VarToUpdate"/></summary>
                GreaterThanOrEqualTo, //SCE_NP_TUS_OPETYPE_GREATER_OR_EQUAL
                /// <summary> Checks if the current value on the TUS server is less than <see cref="TryAndSetVariableRequest.VarToUpdate"/></summary>
                LessThan, //SCE_NP_TUS_OPETYPE_LESS_THAN
                /// <summary> Checks if the current value on the TUS server is less than or equal to <see cref="TryAndSetVariableRequest.VarToUpdate"/></summary>
                LessThanOrEqualTo, //SCE_NP_TUS_OPETYPE_LESS_OR_EQUAL
            }

            /// <summary>
            /// Represents a request to write a 64-bit integer to a single specified user's TUS variable, if a condition is met.
			/// </summary>
            /// <remarks>
            /// The comparison can be read as "The value of the variable on the server must be <see cref="TryAndSetCompareOperator"/> the
            /// one provided". For example: "The value of the variable on the server must be 
            /// greater than the one provided".
            /// </remarks>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class TryAndSetVariableRequest : RequestBase
			{
                internal UserInput tusUser;

                internal VariableInput varToUpdate;

                internal DataContention dataContention;

                internal Int64 compareValue;

                internal TryAndSetCompareOperator compareOperator;

                [MarshalAs(UnmanagedType.I1)]
                internal bool forCrossSave;

                /// <summary>
                /// Information regarding the user provided as input
                /// </summary>
                public UserInput TusUser
                {
                    get { return tusUser; }
                    set { tusUser = value; }
                }

                /// <summary>
                /// The TUS variable to update.
                /// </summary>
                public VariableInput VarToUpdate
                {
                    get { return varToUpdate; }
                    set { varToUpdate = value; }
                }

                /// <summary>
                /// Prevents data contention.
                /// </summary>
                public DataContention DataContention
                {
                    get { return dataContention; }
                    set { dataContention = value; }
                }

                /// <summary>
                /// The 64-bit integer to compare.
                /// </summary>
                public Int64 CompareValue
                {
                    get { return compareValue; }
                    set { compareValue = value; }
                }

                /// <summary>
                /// The type of comparison to make against the variable on the TUS server. See class remarks for details.
                /// </summary>
                public TryAndSetCompareOperator CompareOperator
                {
                    get { return compareOperator; }
                    set { compareOperator = value; }
                }

                /// <summary>
                /// A flag that specifies whether this is a cross-platform save. Use this to ensure compatibility with older platforms.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                    set { forCrossSave = value; }
                }	

				/// <summary>
				/// Initializes a new instance of the <see cref="TryAndSetVariableRequest"/> class.
				/// </summary>
				public TryAndSetVariableRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusTryAndSetVariable)
				{

				}
			}

            /// <summary>
            /// Represents the sorting order requested for friends' TUS variables returned from the server.
            /// </summary>
            public enum FriendsVariableSortingOrder
            {
                /// <summary>  Sort by last update date/time in descending order </summary>
                DescDate = 1, //SCE_NP_TUS_VARIABLE_SORTTYPE_DESCENDING_DATE
                /// <summary> Sort by last update date/time in ascending order </summary>
                AscDate, //SCE_NP_TUS_VARIABLE_SORTTYPE_ASCENDING_DATE
                /// <summary> Sort the TUS variable numerical values in descending order</summary>
                DescValue, //SCE_NP_TUS_VARIABLE_SORTTYPE_DESCENDING_VALUE
                /// <summary> Sort the TUS variable numerical values in ascending order </summary>
                AscValue, //SCE_NP_TUS_VARIABLE_SORTTYPE_ASCENDING_VALUE
            }

            /// <summary>
            /// Represents a request to get a variable from a specific slot for all the friends of the calling user.
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetFriendsVariableRequest : RequestBase
			{
                /// <summary>
                /// Maximum size of the <see cref="PageSize"/>. Set as the default.
				/// </summary>
                public const int MAX_PAGE_SIZE = 100;
                
                internal UInt32 pageSize;
                internal Int32 slotId;		
		        internal FriendsVariableSortingOrder sortingOrder;
		        internal UInt32 startIndex;

                [MarshalAs(UnmanagedType.I1)]
		        internal bool forCrossSave;

                [MarshalAs(UnmanagedType.I1)]
		        internal bool includeMeIfFound;

                /// <summary>
                /// The slot to retrieve variables from.
                /// </summary>
                public Int32 SlotId
                {
                    get { return slotId; }
                    set { slotId = value; }
                }

                /// <summary>
                /// The requested sorting order for the returned variables.
                /// </summary>
                public FriendsVariableSortingOrder SortingOrder
                {
                    get { return sortingOrder; }
                    set { sortingOrder = value; }
                }

                /// <summary>
                /// The start index of the search. The total amount of friends on the server is returned in <see cref="FriendsVariablesResponse.TotalFriends"/>. That value can be greater than the <see cref="MAX_PAGE_SIZE"/>. The index can be used to retrieve additional pages of results.
                /// </summary>
                public UInt32 StartIndex
                {
                    get { return startIndex; }
                    set { startIndex = value; }
                }

                /// <summary>
                /// The number of friends to return. Default of <see cref="MAX_PAGE_SIZE"/>.
                /// </summary>
                public UInt32 PageSize
                {
                    get { return pageSize; }
                    set 
                    {
                        if (value > MAX_PAGE_SIZE)
                        {
                            throw new NpToolkitException("The page size can't be larger than " + MAX_PAGE_SIZE);
                        }
                        pageSize = value; 
                    }
                }

                /// <summary>
                /// A flag that specifies if the variable is for cross-platform save.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                    set { forCrossSave = value; }
                }

                /// <summary>
                /// The calling user is included in the result if it is found in the requested range. Defaults to true.
                /// </summary>
                public bool IncludeMeIfFound
                {
                    get { return includeMeIfFound; }
                    set { includeMeIfFound = value; }
                }	

				/// <summary>
				/// Initializes a new instance of the <see cref="GetFriendsVariableRequest"/> class.
				/// </summary>
				public GetFriendsVariableRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetFriendsVariable)
				{
                    pageSize = MAX_PAGE_SIZE;
                    includeMeIfFound = true;
                    sortingOrder = FriendsVariableSortingOrder.DescDate;
				}
			}

            /// <summary>
            /// Represents a request to get variables from a specific slot for a list of virtual or real users.
			/// </summary>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetUsersVariableRequest : RequestBase
			{
                /// <summary>
                /// Maximum size of the Virtual user or Real user arrays <see cref="VirtualUsersIds"/> and <see cref="RealUsersIds"/>
				/// </summary>
                public const int MAX_NUM_USERS = 100;

                internal UInt32 maxUsersToObtain;

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_NUM_USERS)]
                internal VirtualUserID[] virtualUsersIds = new VirtualUserID[MAX_NUM_USERS];

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_NUM_USERS)]
                internal Core.NpAccountId[] realUsersIds = new Core.NpAccountId[MAX_NUM_USERS];

		        internal Int32 slotId;

                [MarshalAs(UnmanagedType.I1)]
		        internal bool areVirtualUsers;

                [MarshalAs(UnmanagedType.I1)]
		        internal bool forCrossSave;

                /// <summary>
                /// The list of virtual users.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_NUM_USERS"/>.</exception>
                public VirtualUserID[] VirtualUsersIds
                {
                    get
                    {
                        if (maxUsersToObtain == 0) return null;

                        if (areVirtualUsers == false)
                        {
                            throw new NpToolkitException("These are not virtual users.");
                        }

                        VirtualUserID[] output = new VirtualUserID[maxUsersToObtain];

                        Array.Copy(virtualUsersIds, output, (int)maxUsersToObtain);

                        return output;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_NUM_USERS)
                            {
                                throw new NpToolkitException("The size of the array is larger than " + MAX_NUM_USERS);
                            }

                            value.CopyTo(virtualUsersIds, 0);
                            maxUsersToObtain = (UInt32)value.Length;
                            areVirtualUsers = true;
                        }
                        else
                        {
                            maxUsersToObtain = 0;
                            areVirtualUsers = false;
                        }
                    }
                }

                /// <summary>
                /// The list of real users.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_NUM_USERS"/>.</exception>
                public Core.NpAccountId[] RealUsersIds
                {
                    get
                    {
                        if (maxUsersToObtain == 0) return null;

                        if (areVirtualUsers == true)
                        {
                            throw new NpToolkitException("These are not real user Ids. Virtual users are stored here.");
                        }

                        Core.NpAccountId[] output = new Core.NpAccountId[maxUsersToObtain];

                        Array.Copy(realUsersIds, output, (int)maxUsersToObtain);

                        return output;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_NUM_USERS)
                            {
                                throw new NpToolkitException("The size of the array is larger than " + MAX_NUM_USERS);
                            }

                            value.CopyTo(realUsersIds, 0);
                            maxUsersToObtain = (UInt32)value.Length;
                            areVirtualUsers = false;
                        }
                        else
                        {
                            maxUsersToObtain = 0;
                            areVirtualUsers = false;
                        }
                    }
                }

                /// <summary>
                /// The ID of the slot whose variables are requested.
                /// </summary>
                public Int32 SlotId
                {
                    get { return slotId; }
                    set { slotId = value; }
                }

                /// <summary>
                /// A flag that specifies if the variables are for cross-platform save. Defaults to false.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                    set { forCrossSave = value; }
                }

                /// <summary>
                /// A flag that specifies if the users in the list are virtual users. Defaults to false.
                /// </summary>
                public bool AreVirtualUsers
                {
                    get { return areVirtualUsers; }
                }	

				/// <summary>
				/// Initializes a new instance of the <see cref="GetUsersVariableRequest"/> class.
				/// </summary>
				public GetUsersVariableRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetUsersVariable)
				{
                    forCrossSave = false;
                    areVirtualUsers = false;
				}
			}

            /// <summary>
            /// Represents a request to get the data status of a specific slot for a list of virtual or real users.
			/// </summary>
            /// <remarks>
            /// Represents a request to get the data status of a specific slot for a list of virtual or real users.
            /// Only the data status is retrieved, not the data itself. Data status includes information on the owner of the data,
            /// the user who last updated the data, when the data was last updated, the supplementary information associated with
            /// the data and so on.
            /// </remarks>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetUsersDataStatusRequest : RequestBase
			{
                /// <summary>
                /// Maximum size of the Virtual user or Real user arrays <see cref="VirtualUsersIds"/> and <see cref="RealUsersIds"/>
                /// </summary>
                public const int MAX_NUM_USERS = 100;

                internal UInt32 maxUsersToObtain;

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_NUM_USERS)]
                internal VirtualUserID[] virtualUsersIds = new VirtualUserID[MAX_NUM_USERS];

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_NUM_USERS)]
                internal Core.NpAccountId[] realUsersIds = new Core.NpAccountId[MAX_NUM_USERS];

                internal Int32 slotId;

                [MarshalAs(UnmanagedType.I1)]
                internal bool areVirtualUsers;

                [MarshalAs(UnmanagedType.I1)]
                internal bool forCrossSave;

                /// <summary>
                /// The list of virtual users
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_NUM_USERS"/>.</exception>
                public VirtualUserID[] VirtualUsersIds
                {
                    get
                    {
                        if (maxUsersToObtain == 0) return null;

                        if (areVirtualUsers == false)
                        {
                            throw new NpToolkitException("These are not virtual users.");
                        }

                        VirtualUserID[] output = new VirtualUserID[maxUsersToObtain];

                        Array.Copy(virtualUsersIds, output, (int)maxUsersToObtain);

                        return output;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_NUM_USERS)
                            {
                                throw new NpToolkitException("The size of the array is larger than " + MAX_NUM_USERS);
                            }

                            value.CopyTo(virtualUsersIds, 0);
                            maxUsersToObtain = (UInt32)value.Length;
                            areVirtualUsers = true;
                        }
                        else
                        {
                            maxUsersToObtain = 0;
                            areVirtualUsers = false;
                        }
                    }
                }

                /// <summary>
                /// The list of real users
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is larger than <see cref="MAX_NUM_USERS"/>.</exception>
                public Core.NpAccountId[] RealUsersIds
                {
                    get
                    {
                        if (maxUsersToObtain == 0) return null;

                        if (areVirtualUsers == true)
                        {
                            throw new NpToolkitException("These are not real user Ids. Virtual users are stored here.");
                        }

                        Core.NpAccountId[] output = new Core.NpAccountId[maxUsersToObtain];

                        Array.Copy(realUsersIds, output, (int)maxUsersToObtain);

                        return output;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_NUM_USERS)
                            {
                                throw new NpToolkitException("The size of the array is larger than " + MAX_NUM_USERS);
                            }

                            value.CopyTo(realUsersIds, 0);
                            maxUsersToObtain = (UInt32)value.Length;
                            areVirtualUsers = false;
                        }
                        else
                        {
                            maxUsersToObtain = 0;
                            areVirtualUsers = false;
                        }
                    }
                }

                /// <summary>
                /// The ID of the slot whose data status is requested.
                /// </summary>
                public Int32 SlotId
                {
                    get { return slotId; }
                    set { slotId = value; }
                }

                /// <summary>
                /// A flag that specifies if the data statuses are for cross-platform save. Defaults to false.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                    set { forCrossSave = value; }
                }

                /// <summary>
                /// A flag that specifies if the users in the list are virtual users. Defaults to false.
                /// </summary>
                public bool AreVirtualUsers
                {
                    get { return areVirtualUsers; }
                }	

				/// <summary>
				/// Initializes a new instance of the <see cref="GetUsersDataStatusRequest"/> class.
				/// </summary>
				public GetUsersDataStatusRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetUsersDataStatus)
				{
                    forCrossSave = false;
                    areVirtualUsers = false;
				}
			}

            /// <summary>
            /// Represents the sorting order requested for friends' TUS data statuses returned from the server.
            /// </summary>
            public enum FriendsDataStatusSortingOrder
            {
                /// <summary>  Sort by last update date/time in descending order </summary>
                DescDate = 1, //SCE_NP_TUS_DATASTATUS_SORTTYPE_DESCENDING_DATE
                /// <summary>  Sort by last update date/time in ascending order </summary>
                AscDate, //SCE_NP_TUS_DATASTATUS_SORTTYPE_ASCENDING_DATE
            }

            /// <summary>
            /// Represents a request to get the data status of a specific slot for all the friends of the calling user.
			/// </summary>
            /// <remarks>
            /// Represents a request to get the data status of a specific slot for all the friends of the calling user.
            /// Only the data status is retrieved, not the data itself. Data status includes information on the owner of the data,
            /// the user who last updated the data, when the data was last updated, the supplementary information associated with
            /// the data and so on.
            /// </remarks>
			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public class GetFriendsDataStatusRequest : RequestBase
			{
                /// <summary>
                /// Maximum size of the <see cref="PageSize"/>.
                /// </summary>
                public const int MAX_PAGE_SIZE = 100;

                UInt32 pageSize;
		        Int32 slotId;
		        FriendsDataStatusSortingOrder sortingOrder;
		        UInt32 startIndex;
		        bool forCrossSave;
		        bool includeMeIfFound;

                /// <summary>
                /// The number of friends to return. Defaults to <see cref="MAX_PAGE_SIZE"/>
                /// </summary>
                public UInt32 PageSize
                {
                    get { return pageSize; }
                    set
                    {
                        if (value > MAX_PAGE_SIZE)
                        {
                            throw new NpToolkitException("The page size can't be larger than " + MAX_PAGE_SIZE);
                        }
                        pageSize = value;
                    }
                }

                /// <summary>
                /// The ID of the slot whose data status is requested.
                /// </summary>
                public Int32 SlotId
                {
                    get { return slotId; }
                    set { slotId = value; }
                }

                /// <summary>
                /// The requested sorting order for the returned data statuses.
                /// </summary>
                public FriendsDataStatusSortingOrder SortingOrder
                {
                    get { return sortingOrder; }
                    set { sortingOrder = value; }
                }

                /// <summary>
                /// The start index of the search. The total amount of friends on the server will be returned in <see cref="FriendsVariablesResponse.TotalFriends"/>. That value can be greater than the <see cref="MAX_PAGE_SIZE"/>. The index to start the search will then be useful in case pagination is needed.
                /// </summary>
                public UInt32 StartIndex
                {
                    get { return startIndex; }
                    set { startIndex = value; }
                }

                /// <summary>
                /// A flag that specifies if the data status is for cross-platform save. Defaults to false.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                    set { forCrossSave = value; }
                }

                /// <summary>
                /// The calling user will be included in the result if it is found in the requested range. Defaults to true.
                /// </summary>
                public bool IncludeMeIfFound
                {
                    get { return includeMeIfFound; }
                    set { includeMeIfFound = value; }
                }

				/// <summary>
				/// Initializes a new instance of the <see cref="GetFriendsDataStatusRequest"/> class.
				/// </summary>
				public GetFriendsDataStatusRequest()
					: base(ServiceTypes.Tus, FunctionTypes.TusGetFriendsDataStatus)
				{
                    pageSize = MAX_PAGE_SIZE;
                    forCrossSave = false;
                    includeMeIfFound = true;
                    sortingOrder = FriendsDataStatusSortingOrder.DescDate;
				}
			}

			#endregion

			#region Set Variables

			/// <summary>
			/// Sets Title User Storage (TUS) variables for a given user
			/// </summary>
			/// <param name="request">The request parameters required to set a users TUS variables</param>
			/// <param name="response">This response does not have data, only return code</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static int SetVariables(SetVariablesRequest request, Core.EmptyResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusSetVariables(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

			#region Get Variables		

			/// <summary>
			/// TUS variables that were returned from the TUS server
			/// </summary>
			public class VariablesResponse : ResponseBase
			{
				internal bool forCrossSave;

				internal NpVariable[] vars;
				internal NpVariableForCrossSave[] varsForCrossSave;

				/// <summary>
				/// Specifies if the variables returned are for cross save
				/// </summary>
				public bool ForCrossSave
				{
					get { return forCrossSave; }
				}

				/// <summary>
				/// TUS variables
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
				public NpVariable[] Vars
				{
					get 
					{ 
						if (forCrossSave == true)
						{
							throw new NpToolkitException("Vars isn't valid unless 'ForCrossSave' is set to false.");
						}

						return vars; 
					}
				}

				/// <summary>
				/// TUS variables for cross save
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
				public NpVariableForCrossSave[] VarsForCrossSave
				{
					get 
					{
						if (forCrossSave == false)
						{
							throw new NpToolkitException("VarsForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
						}
						return varsForCrossSave; 
					}
				}

				/// <summary>
				/// Read the response data from the plug-in
				/// </summary>
				/// <param name="id">The request id.</param>
				/// <param name="apiCalled">The API called.</param>
				/// <param name="request">The Request object.</param>
				protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
				{
					base.ReadResult(id, apiCalled, request);

					APIResult result;

					MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

					if (result.RaiseException == true) throw new NpToolkitException(result);

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusVariablesBegin);

					Int64 numVars = readBuffer.ReadInt64();
					forCrossSave = readBuffer.ReadBool();

					if (forCrossSave == true)
					{
						varsForCrossSave = new NpVariableForCrossSave[numVars];
					}
					else
					{
						vars = new NpVariable[numVars];
					}

					for (int i = 0; i < numVars; i++)
					{
						if (forCrossSave == true)
						{
							varsForCrossSave[i] = new NpVariableForCrossSave();
							varsForCrossSave[i].Read(readBuffer);
						}
						else
						{
							vars[i] = new NpVariable();
							vars[i].Read(readBuffer);
						}
					}

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusVariablesEnd);

					EndReadResponseBuffer(readBuffer);
				}
			}

			/// <summary>
			/// Get a specified users TUS variables from specified slots
			/// </summary>
			/// <param name="request">The parameters required to retrieve TUS variables </param>
			/// <param name="response">The requested TUS variables that will be set upon successful completion</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static int GetVariables(GetVariablesRequest request, VariablesResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusGetVariables(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

			#region Add To And Get Variable

            #region Obsolete
            /// <summary>
			/// Contains the result of the add and get TUS variable operation
			/// </summary>
            [System.Obsolete("AtomicAddToAndGetVariableResponse is deprecated, please use VariablesResponse instead.")]
			public class AtomicAddToAndGetVariableResponse : ResponseBase
			{
				internal bool forCrossSave;

				internal NpVariable var;
				internal NpVariableForCrossSave varForCrossSave;

				/// <summary>
				/// Specifies if the variable returned is for cross save
				/// </summary>
				public bool ForCrossSave
				{
					get { return forCrossSave; }
				}

				/// <summary>
				/// TUS variable
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
				public NpVariable Var
				{
					get
					{
						if (forCrossSave == true)
						{
							throw new NpToolkitException("Vars isn't valid unless 'ForCrossSave' is set to false.");
						}

						return var;
					}
				}

				/// <summary>
				/// TUS variable for cross save
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
				public NpVariableForCrossSave VarForCrossSave
				{
					get
					{
						if (forCrossSave == false)
						{
							throw new NpToolkitException("VarsForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
						}
						return varForCrossSave;
					}
				}

				/// <summary>
				/// Read the response data from the plug-in
				/// </summary>
				/// <param name="id">The request id.</param>
				/// <param name="apiCalled">The API called.</param>
				/// <param name="request">The Request object.</param>
				protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
				{
					base.ReadResult(id, apiCalled, request);

					APIResult result;

					MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

					if (result.RaiseException == true) throw new NpToolkitException(result);

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusAtomicAddToAndGetVariableBegin);

					forCrossSave = readBuffer.ReadBool();

					if (forCrossSave == true)
					{
						varForCrossSave = new NpVariableForCrossSave();
						varForCrossSave.Read(readBuffer);
					}
					else
					{
						var = new NpVariable();
						var.Read(readBuffer);
					}

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusAtomicAddToAndGetVariableEnd);

					EndReadResponseBuffer(readBuffer);
				}
			}

            /// <summary>
            /// /// Adds and gets a users TUS variable in a single operation - Obsolete
            /// </summary>
            [System.Obsolete("AddToAndGetVariable using AtomicAddToAndGetVariableResponse is obsolete, please use VariablesResponse version instead.")]
            public static int AddToAndGetVariable(AddToAndGetVariableRequest request, AtomicAddToAndGetVariableResponse response)
            {
                throw new NpToolkitException("AddToAndGetVariable using AtomicAddToAndGetVariableResponse object is Obsolete. Use VariablesResponse version instead.");
            }
            #endregion

            /// <summary>
			/// Adds and gets a users TUS variable in a single operation
			/// </summary>
			/// <param name="request">The parameters specifying the users slot and value to add to </param>
			/// <param name="response"> Upon successful completion, this will contain the new value of the TUS variable</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int AddToAndGetVariable(AddToAndGetVariableRequest request, VariablesResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusAddToAndGetVariable(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

			#region Set Data

			/// <summary>
			/// Sets a specified users TUS binary data
			/// </summary>
			/// <param name="request">The parameters required for setting a users TUS binary data</param>
			/// <param name="response">This response does not have data, only return code</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static int SetData(SetDataRequest request, Core.EmptyResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusSetData(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

			#region Get Data

			/// <summary>
			/// TUS data that was returned from the TUS server
			/// </summary>
			public class GetDataResponse : ResponseBase
			{
				internal bool forCrossSave;

				internal TusDataStatus tusDataStatus;
				internal TusDataStatusForCrossSave tusDataStatusForCrossSave;

				internal byte[] data;

				/// <summary>
				/// The TUS data
				/// </summary>
				public byte[] Data
				{
					get { return data; }
				}

				/// <summary>
				/// Specifies if the data returned is for cross save
				/// </summary>
				public bool ForCrossSave
				{
					get { return forCrossSave; }
				}

                #region Obsolete
				/// <summary>
				/// The status of the data.
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
                [System.Obsolete("Use DataStatus instead.")]
				public NpTusDataStatus Status
				{
					get
					{
						if (forCrossSave == true)
						{
							throw new NpToolkitException("Vars isn't valid unless 'ForCrossSave' is set to false.");
						}

						return null;
					}
				}

				/// <summary>
				/// The status of the data when cross save us used
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
                [System.Obsolete("Use DataStatusForCrossSave instead.")]
				public NpTusDataStatusForCrossSave StatusForCrossSave
				{
					get
					{
						if (forCrossSave == false)
						{
							throw new NpToolkitException("VarsForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
						}
						return null;
					}
				}
                #endregion

                /// <summary>
				/// The status of the data.
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
				public TusDataStatus DataStatus
				{
					get
					{
						if (forCrossSave == true)
						{
							throw new NpToolkitException("Vars isn't valid unless 'ForCrossSave' is set to false.");
						}

						return tusDataStatus;
					}
				}

				/// <summary>
				/// The status of the data when cross save us used
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
                public TusDataStatusForCrossSave DataStatusForCrossSave
				{
					get
					{
						if (forCrossSave == false)
						{
							throw new NpToolkitException("VarsForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
						}
                        return tusDataStatusForCrossSave;
					}
				}

				/// <summary>
				/// Read the response data from the plug-in
				/// </summary>
				/// <param name="id">The request id.</param>
				/// <param name="apiCalled">The API called.</param>
				/// <param name="request">The Request object.</param>
				protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
				{
					base.ReadResult(id, apiCalled, request);

					APIResult result;

					MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

					if (result.RaiseException == true) throw new NpToolkitException(result);

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusDataBegin);

					readBuffer.ReadData(ref data);

					forCrossSave = readBuffer.ReadBool();

					if (forCrossSave == true)
					{
						tusDataStatusForCrossSave = new TusDataStatusForCrossSave();
						tusDataStatusForCrossSave.Read(readBuffer);
					}
					else
					{
						tusDataStatus = new TusDataStatus();
						tusDataStatus.Read(readBuffer);
					}

					readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusDataEnd);

					EndReadResponseBuffer(readBuffer);
				}
			}


			/// <summary>
			/// Gets a specified user's TUS binary data
			/// </summary>
			/// <param name="request">The parameters required to retrieve a users TUS binary data</param>
			/// <param name="response">On successful completion, this will contain the requested users binary data</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static int GetData(GetDataRequest request, GetDataResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusGetData(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

			#region Delete Data

			/// <summary>
			/// Deletes data from specified slots
			/// </summary>
			/// <param name="request">The required parameters for deleting a users TUS data</param>
			/// <param name="response">This response does not have data, only return code</param>
			/// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static int DeleteData(DeleteDataRequest request, Core.EmptyResponse response)
			{
				APIResult result;

				if (response.locked == true)
				{
					throw new NpToolkitException("Response object is already locked");
				}

				int ret = PrxTusDeleteData(request, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				RequestBase.FinaliseRequest(request, response, ret);

				return ret;
			}

			#endregion

            // SDK 5.0 new methods

            #region Try And Set Variable

            /// <summary>
            /// Deletes data from specified slots
            /// </summary>
            /// <param name="request">The required parameters for deleting a users TUS data</param>
            /// <param name="response">This response does not have data, only return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int TryAndSetVariable(TryAndSetVariableRequest request, VariablesResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion < 0x05000000)
                {
                    throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 5.0 or greater.");
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxTusTryAndSetVariable(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Friends Variable

            /// <summary>
            /// Contains a list of the variables that the user's friends have in a specific slot.
            /// </summary>
            public class FriendsVariablesResponse : ResponseBase
            {
                internal UInt32 totalFriends;

                internal bool forCrossSave;

                internal NpVariable[] vars;
                internal NpVariableForCrossSave[] varsForCrossSave;

                /// <summary>
                /// The total number of friends on the %TUS server. This can be used for pagination.
                /// </summary>
                public UInt32 TotalFriends
                {
                    get { return totalFriends; }
                }

                /// <summary>
                /// A flag that specifies if the variables returned are for a cross-platform save.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                }

                /// <summary>
                /// The TUS variables.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
                public NpVariable[] Vars
                {
                    get
                    {
                        if (forCrossSave == true)
                        {
                            throw new NpToolkitException("Vars isn't valid unless 'ForCrossSave' is set to false.");
                        }

                        return vars;
                    }
                }

                /// <summary>
                /// The TUS variables if the variables returned are for a cross-platform save.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
                public NpVariableForCrossSave[] VarsForCrossSave
                {
                    get
                    {
                        if (forCrossSave == false)
                        {
                            throw new NpToolkitException("VarsForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
                        }
                        return varsForCrossSave;
                    }
                }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusFriendsVariablesBegin);

                    totalFriends = readBuffer.ReadUInt32();

                    Int64 numVars = readBuffer.ReadInt64();
                    forCrossSave = readBuffer.ReadBool();

                    if (forCrossSave == true)
                    {
                        varsForCrossSave = new NpVariableForCrossSave[numVars];
                    }
                    else
                    {
                        vars = new NpVariable[numVars];
                    }

                    for (int i = 0; i < numVars; i++)
                    {
                        if (forCrossSave == true)
                        {
                            varsForCrossSave[i] = new NpVariableForCrossSave();
                            varsForCrossSave[i].Read(readBuffer);
                        }
                        else
                        {
                            vars[i] = new NpVariable();
                            vars[i].Read(readBuffer);
                        }
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusFriendsVariablesEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Deletes data from specified slots
            /// </summary>
            /// <param name="request">The required parameters for deleting a users TUS data</param>
            /// <param name="response">This response does not have data, only return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetFriendsVariable(GetFriendsVariableRequest request, FriendsVariablesResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion < 0x05000000)
                {
                    throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 5.0 or greater.");
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxTusGetFriendsVariable(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Users Variable

            /// <summary>
            /// Deletes data from specified slots
            /// </summary>
            /// <param name="request">The required parameters for deleting a users TUS data</param>
            /// <param name="response">This response does not have data, only return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetUsersVariable(GetUsersVariableRequest request, VariablesResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion < 0x05000000)
                {
                    throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 5.0 or greater.");
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxTusGetUsersVariable(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Users Data Status

            /// <summary>
            /// TUS data that was returned from the TUS server
            /// </summary>
            public class DataStatusesResponse : ResponseBase
            {
                internal bool forCrossSave;

                internal TusDataStatus[] statuses;
                internal TusDataStatusForCrossSave[] statusesForCrossSave;

                /// <summary>
                /// Specifies if the variables returned are for cross save
                /// </summary>
                public bool ForCrossSave
                {
                    get { return forCrossSave; }
                }

                /// <summary>
                /// The TUS statuses.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
                public TusDataStatus[] Statuses
                {
                    get
                    {
                        if (forCrossSave == true)
                        {
                            throw new NpToolkitException("Statuses isn't valid unless 'ForCrossSave' is set to false.");
                        }

                        return statuses;
                    }
                }

                /// <summary>
                /// The TUS statuses if the statuses returned are for a cross-platform save.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
                public TusDataStatusForCrossSave[] StatusesForCrossSave
                {
                    get
                    {
                        if (forCrossSave == false)
                        {
                            throw new NpToolkitException("StatusesForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
                        }
                        return statusesForCrossSave;
                    }
                }

                internal void Read(MemoryBuffer readBuffer)
                {
                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusDataStatusesBegin);

                    Int64 numStatuses = readBuffer.ReadInt64();
                    forCrossSave = readBuffer.ReadBool();

                    if (forCrossSave == true)
                    {
                        statusesForCrossSave = new TusDataStatusForCrossSave[numStatuses];

                        for (int i = 0; i < numStatuses; i++)
                        {
                            statusesForCrossSave[i] = new TusDataStatusForCrossSave();
                            statusesForCrossSave[i].Read(readBuffer);
                        }
                    }
                    else
                    {
                        statuses = new TusDataStatus[numStatuses];

                        for (int i = 0; i < numStatuses; i++)
                        {
                            statuses[i] = new TusDataStatus();
                            statuses[i].Read(readBuffer);
                        }
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusDataStatusesEnd);
                }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    Read(readBuffer);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Deletes data from specified slots
            /// </summary>
            /// <param name="request">The required parameters for deleting a users TUS data</param>
            /// <param name="response">This response does not have data, only return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetUsersDataStatus(GetUsersDataStatusRequest request, DataStatusesResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion < 0x05000000)
                {
                    throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 5.0 or greater.");
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxTusGetUsersDataStatus(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Friends Data Status

            /// <summary>
            /// TUS data that was returned from the TUS server
            /// </summary>
            public class FriendsDataStatusesResponse : ResponseBase
            {
                internal UInt64 totalFriends;
                internal DataStatusesResponse friendsStatuses = new DataStatusesResponse();

                /// <summary>
                /// The total number of friends on the TUS server. This can be used for pagination.
                /// </summary>
                public UInt64 TotalFriends
                {
                    get { return totalFriends; }
                }

                /// <summary>
                /// A flag that specifies if the statuses returned are for a cross-platform save.
                /// </summary>
                public bool ForCrossSave
                {
                    get { return friendsStatuses.forCrossSave; }
                }

                /// <summary>
                /// The TUS statuses.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to false.</exception>
                public TusDataStatus[] Statuses
                {
                    get
                    {
                        if (friendsStatuses.forCrossSave == true)
                        {
                            throw new NpToolkitException("Statuses isn't valid unless 'ForCrossSave' is set to false.");
                        }

                        return friendsStatuses.statuses;
                    }
                }

                /// <summary>
                /// The TUS statuses if the statuses returned are for a cross-platform save.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if <see cref="ForCrossSave"/> isn't set to true.</exception>
                public TusDataStatusForCrossSave[] StatusesForCrossSave
                {
                    get
                    {
                        if (friendsStatuses.forCrossSave == false)
                        {
                            throw new NpToolkitException("StatusesForCrossSave isn't valid unless 'ForCrossSave' is set to true.");
                        }
                        return friendsStatuses.statusesForCrossSave;
                    }
                }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusFriendsDataStatusesBegin);

                    totalFriends = readBuffer.ReadUInt32();

                    friendsStatuses.Read(readBuffer);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.TusFriendsDataStatusesEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Deletes data from specified slots
            /// </summary>
            /// <param name="request">The required parameters for deleting a users TUS data</param>
            /// <param name="response">This response does not have data, only return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetFriendsDataStatus(GetFriendsDataStatusRequest request, FriendsDataStatusesResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion < 0x05000000)
                {
                    throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 5.0 or greater.");
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxTusGetFriendsDataStatus(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Obsolete Types

            /// <summary>
            /// Represents a TUS (title user storage) variable - Renamed to VariableInput in SDK 5.0
            /// </summary>
            [System.Obsolete("Variable is deprecated, please use VariableInput instead.")]
            public struct Variable
            {
                /// <summary>
                /// The TUS variable value
                /// </summary>
                public Int64 Value
                {
                    get { return 0; }
                    set { }
                }

                /// <summary>
                /// The slot that the variable belongs to
                /// </summary>
                public Int32 SlotId
                {
                    get { return 0; }
                    set { }
                }
            }
            #endregion
        }
	}
}
